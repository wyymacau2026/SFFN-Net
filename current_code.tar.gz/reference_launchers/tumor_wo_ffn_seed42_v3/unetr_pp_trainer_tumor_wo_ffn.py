"""Full SFFN-Net minus exactly four post-fusion FFNs; isolated subclass."""
from __future__ import annotations

import hashlib
import json
import os
import pickle
from collections import OrderedDict
from pathlib import Path

from ffn_identity import apply_ffn_identity
from unetr_pp.training.network_training.unetr_pp_trainer_tumor import unetr_pp_trainer_tumor

SPLIT_SHA = "3c747eff74412b5c60c02fc80754b11785342019c62ada2a63073191ea90517e"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


class unetr_pp_trainer_tumor_wo_ffn(unetr_pp_trainer_tumor):
    """Inherit full construction/initialization; transform immediately before SGD."""

    def do_split(self):
        require(self.fold == 0, "Only frozen fold 0 is permitted")
        path = Path(self.dataset_directory) / "splits_final.pkl"
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == SPLIT_SHA, "Frozen split SHA256 differs")
        split = pickle.loads(raw)[0]
        train, val = ([str(x) for x in split[k]] for k in ("train", "val"))
        require(len(train) == len(set(train)) == 387, "Training IDs differ")
        require(len(val) == len(set(val)) == 97, "Validation IDs differ")
        require(not set(train) & set(val), "Training/validation overlap")
        require(set(train) | set(val) == set(map(str, self.dataset)), "Dataset IDs differ")
        self.dataset_tr = OrderedDict((c, self.dataset[c]) for c in train)
        self.dataset_val = OrderedDict((c, self.dataset[c]) for c in val)
        self.print_to_log_file("STRICT TUMOR SPLIT AUDIT PASSED: train=387 val=97 overlap=0 total=484")

    def initialize_optimizer_and_scheduler(self):
        require(getattr(self, "optimizer", None) is None, "An optimizer already exists")
        require(os.environ.get("EXPERIMENT_SEED") == "42", "This entry is seed42 only")
        seed_audit = getattr(self, "ffn_seed_audit", None)
        require(isinstance(seed_audit, dict) and seed_audit.get("effective_seed") == 42,
                "No verified post-constructor seed42 receipt")
        # Parent initialize_network (including all original initialization) has
        # finished. Do not copy/reimplement it or perform another global init.
        report = apply_ffn_identity(
            self.network, optimizer=None, expected_fca_class="FCA",
            project_root=os.environ["SFFN_PROJECT_ROOT"],
        )
        report.update({"trainer": type(self).__name__, "seed": 42, "fold": 0,
                       "config": dict(MSS_en=True, FCA_en=True, FCA2_en=True),
                       "max_num_epochs": int(self.max_num_epochs), "initial_lr": float(self.initial_lr),
                       "hook": "after inherited initialize_network; before inherited optimizer creation",
                       "from_scratch": True,
                       "seed_initialization_audit": seed_audit})
        self.ffn_architecture_report = report
        if os.environ.get("FFN_DISPOSABLE_PREFLIGHT") == "1":
            # The disposable probe uses the real loss but creates no optimizer.
            return
        super().initialize_optimizer_and_scheduler()
        optimized = [p for group in self.optimizer.param_groups for p in group["params"]]
        registered = list(self.network.parameters())
        require(len(optimized) == len(registered) and {id(p) for p in optimized} == {id(p) for p in registered},
                "Optimizer parameters do not exactly match the ablated network")
        require(not self.optimizer.state, "A fresh optimizer must have no restored state")
        report["optimizer_parameter_identity_verified"] = True
        report["optimizer_class"] = type(self.optimizer).__name__
        path = Path(self.output_folder) / "ablation_architecture_audit.json"
        with path.open("x", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        self.print_to_log_file("ABLATION=w/o_FFN ONLY_TARGETS=FCA0.FFN,FCA1.FFN,FCA2.FFN,FCA3.FFN")
        self.print_to_log_file("MSS_en=True FCA_en=True FCA2_en=True; MFCA/DASI/MSPLCK/SS2D/PSA retained")
        self.print_to_log_file("NOTE: inherited parameter/FLOP lines above describe the pre-ablation full model, NOT ablation efficiency")
        self.print_to_log_file("ABLATION_TRAINABLE_PARAMETERS=" + str(sum(p.numel() for p in registered if p.requires_grad)))
        self.print_to_log_file("ARCHITECTURE_AUDIT=" + str(path))
