#!/usr/bin/env python3
"""Isolated full-SFFN Tumor w/o FFN seed42. Default: read-only audit.

--run: CPU fixtures + disposable real-GPU forward/backward, then detached
training only if EVERY check passes. Source modules/root config stay unchanged.
"""
from __future__ import annotations

import argparse
import ast
import functools
import hashlib
import json
import os
import pickle
import platform
import random
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/root/autodl-tmp/unetr_plus_plus-main")
HERE = Path(__file__).resolve().parent
OUT_REL = "output_tumor_ablation_387_97/w_o_ffn/fold0/seed_42"
TASK_REL = "DATASET_Tumor/unetr_pp_raw/unetr_pp_raw_data/Task03_tumor/Task003_tumor"
FOLD_TAIL = "unetr_pp/3d_fullres/Task003_tumor/unetr_pp_trainer_tumor__unetr_pp_Plansv2.1/fold_0"
SESSION = "tumor_wo_ffn_s42_train"
SOURCE_SHA = {
    "unetr_pp/network_architecture/tumor/unetr_pp_tumor.py": "96fdbdc9c15b9924cdc0aad1011594a209c48181076da5183432f0536ad99b9c",
    "unetr_pp/network_architecture/tumor/model_components.py": "b23e50bfaddace75b2f8fe1ea7fe54b27f364b940ae51161a930a5760c03786c",
    "unetr_pp/network_architecture/tumor/transformerblock.py": "55c3a665970405b7efe5f59a65805b5f8b7bb7ad834f00190dbe786dc430f3ae",
    "unetr_pp/network_architecture/mamba.py": "903c8f90ee852474806a86bdd5db34af176ee4d38bdbcce61bc66dae01af7a2c",
    "unetr_pp/network_architecture/common.py": "a59f51f12b9a6ffde99ed29b9376f3e2e715a8bf0e4ca1d49cd4ff18eb0e43aa",
    "unetr_pp/training/network_training/unetr_pp_trainer_tumor.py": "e48dd1fd90198fa670f55aed55af24f2b22554283d90cca078cdc7c4fbdebb96",
    "unetr_pp/training/network_training/network_trainer_tumor.py": "85d9c694ce28a1fd5441ec85f056921cb5167522648b747b51c1425d354f436f",
    "unetr_pp/training/network_training/Trainer_tumor.py": "eabbf36e43a1c227c90c43417f36304f6f7edccf87c25436255b7079bebca3c7",
}
SPLIT_SHA = "3c747eff74412b5c60c02fc80754b11785342019c62ada2a63073191ea90517e"
PACKAGE_FILES = ("run_tumor_wo_ffn_seed42.py", "unetr_pp_trainer_tumor_wo_ffn.py",
                 "ffn_identity.py", "test_ffn_identity_cpu.py", "config.yaml")


def require(condition, message):
    if not condition:
        raise RuntimeError("STOP: " + message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def flags(path):
    values = {}
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.split("#", 1)[0].strip()
        if line:
            key, value = line.split(":", 1)
            require(key.strip() not in values, "Duplicate configuration key: " + key.strip())
            values[key.strip()] = value.strip().lower()
    return values


def unchanged(manifest):
    for name, digest in manifest.items():
        require(sha(Path(name)) == digest, "Input changed: " + name)


def unused_output_tree(out):
    """Accept nonexistent output or ordinary directories only, NEVER files.

    Importing unetr_pp.paths can create O/unetr_pp before model initialization.
    Such a directory skeleton is not a checkpoint and does not require deletion.
    Hidden files, symlinks and special entries are all rejected.
    """
    require(not out.is_symlink(), "Output is a symlink")
    if not out.exists():
        return 0
    require(out.is_dir(), "Output is not a directory")
    entries = list(out.rglob("*"))
    unsafe = [str(p) for p in entries if p.is_symlink() or not p.is_dir()]
    require(not unsafe, "Output is nonempty (files/links/special entries); no resume/overwrite: " + repr(unsafe[:10]))
    return len(entries)


def audit():
    require("a335-0b76b318" in platform.node(), "Not the original Tumor instance")
    root = ROOT.resolve(strict=True)
    out = root / OUT_REL
    skeleton_directories = unused_output_tree(out)
    tracked = {}
    for rel, expected in SOURCE_SHA.items():
        p = root / rel
        require(p.is_file(), "Missing source: " + str(p))
        actual = sha(p)
        require(actual == expected, f"Source SHA256 differs: {p}; actual={actual}")
        tracked[str(p)] = actual
    for name in PACKAGE_FILES:
        p = HERE / name
        require(p.is_file(), "Missing package file: " + str(p))
        tracked[str(p)] = sha(p)
    expected_flags = dict(MSS_en="true", FCA_en="true", FCA2_en="true")
    for p in (root / "config.yaml", HERE / "config.yaml"):
        require(flags(p) == expected_flags, "Complete SFFN switches are not all True: " + str(p))
        tracked[str(p)] = sha(p)
    task = root / TASK_REL
    sp = task / "splits_final.pkl"
    require(sha(sp) == SPLIT_SHA, "Frozen split SHA256 differs")
    tracked[str(sp)] = SPLIT_SHA
    plan_files = sorted(task.glob("*plans*.pkl"))
    require(plan_files, "No dataset plans files found")
    for p in plan_files:
        tracked[str(p)] = sha(p)
    for rel in ("unetr_pp/run/default_configuration.py", "unetr_pp/paths.py", "unetr_pp/configuration.py"):
        p = root / rel
        require(p.is_file(), "Missing training configuration source: " + str(p))
        tracked[str(p)] = sha(p)
    split = pickle.loads(sp.read_bytes())[0]
    train, val = ([str(x) for x in split[k]] for k in ("train", "val"))
    require(len(train) == len(set(train)) == 387 and len(val) == len(set(val)) == 97,
            "Split counts/unique IDs differ")
    require(not set(train) & set(val), "Training/validation overlap")
    for key, cases in (("train", train), ("val", val)):
        p = root / "experiment_manifests/tumor_fold0" / f"{key}_cases.txt"
        require(p.read_text(encoding="utf-8") == "\n".join(cases) + "\n", "Frozen manifest differs")
        tracked[str(p)] = sha(p)
    stage = task / "nnFormerData_plans_v2.1_stage0"
    for ext in ("npz", "pkl", "npy"):
        ids = {p.stem for p in stage.glob("*." + ext) if p.stat().st_size > 0}
        require(set(train) | set(val) <= ids, "Missing preprocessed " + ext)
    gt_ids = {p.name[:-7] for p in (task / "gt_segmentations").glob("*.nii.gz") if p.stat().st_size > 0}
    require(set(train) | set(val) <= gt_ids, "Missing GT masks")
    reference = root / "output_tumor_387_97/fold0/seed_42" / FOLD_TAIL
    require((reference / "model_best.model").is_file(), "Complete SFFN seed42 checkpoint is absent (never loaded)")
    debug = reference / "debug.json"
    require(debug.is_file(), "Reference debug.json missing; need recorded training schedule")
    tracked[str(debug)] = sha(debug)
    reference_debug = json.loads(debug.read_text())
    for key in ("max_num_epochs", "initial_lr", "num_batches_per_epoch", "num_val_batches_per_epoch", "weight_decay", "fp16", "deterministic"):
        require(key in reference_debug, "Reference debug.json lacks " + key)
    print("SPLIT_AND_DATA_OK: train=387 val=97 overlap=0; NPZ/PKL/NPY/GT complete", flush=True)
    print("FLAGS_OK: MSS_en=True FCA_en=True FCA2_en=True; FCA class=FCA", flush=True)
    print("REFERENCE_SCHEDULE=" + json.dumps({k: reference_debug[k] for k in (
        "max_num_epochs", "initial_lr", "num_batches_per_epoch", "num_val_batches_per_epoch", "weight_decay", "fp16", "deterministic")}), flush=True)
    print(f"OUTPUT_UNUSED_OK: ordinary subdirectories={skeleton_directories}; files=0 links=0; path={out}", flush=True)
    return dict(source_sha256=tracked, reference_debug=str(debug), output=str(out),
                split_sha256=SPLIT_SHA, seed=42, variant="SFFN-Net w/o four post-fusion FFNs")


def idle_gpu():
    require(shutil.which("nvidia-smi") is not None, "nvidia-smi unavailable")
    p = subprocess.run(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"],
                       text=True, capture_output=True, check=True)
    require(not p.stdout.strip(), "GPU has compute processes; stop instead of competing: " + p.stdout.strip())


def environment(preflight=False, probe_results=None):
    e = os.environ.copy()
    e.update(PYTHONHASHSEED="42", EXPERIMENT_SEED="42", CUDA_VISIBLE_DEVICES="0",
             SFFN_PROJECT_ROOT=str(ROOT), PYTHONDONTWRITEBYTECODE="1",
             RESULTS_FOLDER=str(ROOT / OUT_REL),
             unetr_pp_preprocessed=str(ROOT / "DATASET_Tumor/unetr_pp_raw/unetr_pp_raw_data/Task03_tumor"),
             unetr_pp_raw_data_base=str(ROOT / "DATASET_Tumor/unetr_pp_raw"))
    e["PYTHONPATH"] = os.pathsep.join([str(HERE), str(ROOT)] + ([e["PYTHONPATH"]] if e.get("PYTHONPATH") else []))
    if preflight:
        require(probe_results is not None, "Probe must have a separate RESULTS_FOLDER")
        probe_results = Path(os.path.abspath(probe_results))
        log_root = Path(os.path.abspath(ROOT / "run_logs"))
        require(probe_results.is_relative_to(log_root), "Probe results must stay inside run_logs")
        e["RESULTS_FOLDER"] = str(probe_results)
        e["FFN_DISPOSABLE_PREFLIGHT"] = "1"
    else:
        e.pop("FFN_DISPOSABLE_PREFLIGHT", None)
    return e


def literal(value):
    if isinstance(value, str):
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return value
    return value


def reset_seed_after_constructor(trainer, np, torch):
    """Reset global streams only while the trainer has NO network/generators.

    The pinned parent may reset streams to 12345 in __init__. Resetting only
    before __init__ is insufficient. No weights, buffers or optimizer state
    may exist here; therefore no initialized model is being reinitialized.
    """
    require(os.environ.get("EXPERIMENT_SEED") == "42" and os.environ.get("PYTHONHASHSEED") == "42",
            "Both experiment/hash seed must be supplied as 42 at process startup")
    require(getattr(trainer, "was_initialized", None) is False, "Trainer already initialized before reseeding")
    for name in ("network", "optimizer", "tr_gen", "val_gen"):
        require(getattr(trainer, name, None) is None, "Cannot safely reseed after creation of " + name)
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    require(torch.initial_seed() == 42, "Torch seed reset did not take effect")
    actual = np.random.get_state()
    expected = np.random.RandomState(42).get_state()
    require(actual[0] == expected[0] and np.array_equal(actual[1], expected[1]) and actual[2:] == expected[2:],
            "NumPy seed reset did not take effect")
    require(random.getstate() == random.Random(42).getstate(), "Python seed reset did not take effect")
    receipt = dict(effective_seed=42, phase="after parent constructor; before augmentation/network/optimizer",
                   python_hash_seed=os.environ["PYTHONHASHSEED"],
                   network_exists=False, optimizer_exists=False, augmentation_generators_exist=False,
                   numpy_python_torch_initial_states_verified=True)
    trainer.ffn_seed_audit = receipt
    return receipt


def construct(probe_folder=None):
    import numpy as np
    import torch
    from unetr_pp.run.default_configuration import get_default_configuration
    from unetr_pp.network_architecture.tumor import model_components as model
    from unetr_pp_trainer_tumor_wo_ffn import unetr_pp_trainer_tumor_wo_ffn
    require(all(x is True for x in (model.MSS_en, model.FCA_en, model.FCA2_en)), "Imported SFFN switches differ")
    reference_path = ROOT / "output_tumor_387_97/fold0/seed_42" / FOLD_TAIL / "debug.json"
    ref = json.loads(reference_path.read_text())
    reference_deterministic = literal(ref["deterministic"])
    require(type(reference_deterministic) is bool, "Reference deterministic flag is not Boolean")
    random.seed(42); np.random.seed(42); torch.manual_seed(42); torch.cuda.manual_seed_all(42)
    plans, folder, data, batch_dice, stage, cls = get_default_configuration(
        "3d_fullres", "Task003_tumor", "unetr_pp_trainer_tumor", "unetr_pp_Plansv2.1")
    require(Path(data).resolve() == (ROOT / TASK_REL).resolve(), "Resolved dataset path differs")
    require(stage == 0 and cls.__name__ == "unetr_pp_trainer_tumor", "Resolved trainer/stage differs")
    target = probe_folder if probe_folder is not None else Path(folder)
    require(probe_folder is not None or Path(folder).is_relative_to(ROOT / OUT_REL), "Resolved output escapes seed42 directory")
    seed_calls, original = [], []
    def trace_seed(owner, name, label):
        fn = getattr(owner, name)
        @functools.wraps(fn)
        def wrapper(seed=None, *args, **kwargs):
            seed_calls.append((label, seed))
            return fn(seed, *args, **kwargs)
        original.append((owner, name, fn))
        setattr(owner, name, wrapper)
    trace_seed(np.random, "seed", "numpy")
    trace_seed(random, "seed", "python")
    trace_seed(torch, "manual_seed", "torch")
    trace_seed(torch.cuda, "manual_seed_all", "cuda")
    try:
        tr = unetr_pp_trainer_tumor_wo_ffn(plans, 0, output_folder=str(target), dataset_directory=data,
                                         batch_dice=batch_dice, stage=stage, unpack_data=True,
                                         deterministic=reference_deterministic, fp16=False)
        parent_seed_calls = list(seed_calls)
        # Actual user-reported parent resets to 12345. Do not delete the
        # diagnostic: retain it and explicitly correct the effective streams.
        require(all(value in (42, 12345) for _, value in parent_seed_calls),
                "Unexpected parent seed policy: " + repr(parent_seed_calls))
        receipt = reset_seed_after_constructor(tr, np, torch)
    finally:
        for owner, name, fn in original:
            setattr(owner, name, fn)
    last = dict(seed_calls)
    require(all(last.get(label) == 42 for label in ("python", "numpy", "torch", "cuda")),
            "Effective post-constructor streams are not all seed42: " + repr(seed_calls))
    require(torch.initial_seed() == 42, "Torch seed differs after constructor")
    receipt["parent_seed_calls_before_correction"] = parent_seed_calls
    receipt["all_seed_calls_including_correction"] = seed_calls
    receipt["reference_deterministic"] = reference_deterministic
    for key in ("max_num_epochs", "initial_lr", "num_batches_per_epoch", "num_val_batches_per_epoch", "weight_decay", "fp16", "deterministic"):
        require(literal(ref[key]) == getattr(tr, key),
                f"Reference schedule mismatch {key}: full={ref[key]} ablation={getattr(tr, key)}")
    require(tr.fp16 is False, "This audited preflight is FP32; reference precision differs")
    print("PARENT_CONSTRUCTOR_SEED_CALLS=" + repr(parent_seed_calls), flush=True)
    print("SEED42_EFFECTIVE_AFTER_CONSTRUCTOR_VERIFIED=" + repr(last), flush=True)
    print("REFERENCE_SCHEDULE_AND_LOSS_IMPLEMENTATION_INHERITED", flush=True)
    return tr


def gpu_probe(run_folder):
    import numpy as np
    import torch
    require(os.environ.get("FFN_DISPOSABLE_PREFLIGHT") == "1", "Probe mode missing")
    require(torch.cuda.is_available(), "CUDA unavailable")
    manifest = json.loads((run_folder / "input_audit.json").read_text())
    unchanged(manifest["source_sha256"])
    tr = construct(run_folder / "disposable_model")
    tr.initialize(training=False)
    require(torch.initial_seed() == 42 and torch.cuda.initial_seed() == 42,
            "CPU/CUDA initial seed changed during model initialization")
    require(tr.optimizer is None, "Probe must not construct an optimizer")
    require(int(tr.batch_size) == 2 and list(map(int, tr.patch_size)) == [128, 128, 128], "Plans patch/batch differ")
    require(tr.input_channels == 4 and tr.num_classes == 4, "Channel/class count differs")
    net = tr.network
    enc = net.unetr_pp_encoder
    components = {"MSPLCK": enc.MSS.lsblock, "SS2D": enc.MSS.op, "PSA": enc.MSS.mlp}
    for i in range(4):
        fca = getattr(enc, f"FCA{i}")
        require(type(fca.FFN) is torch.nn.Identity, "A target FFN remains")
        components[f"MFCA{i}"] = fca.Fre
        components[f"DASI{i}"] = fca.DASI
        components[f"IdentityFFN{i}"] = fca.FFN
    calls = {key: 0 for key in components}
    def counter(key):
        def hook(module, inputs, output):
            calls[key] += 1
        return hook
    handles = [m.register_forward_hook(counter(k)) for k, m in components.items()]
    net.train(); net.zero_grad(set_to_none=True)
    torch.cuda.reset_peak_memory_stats()
    x = torch.randn(2, 4, 128, 128, 128, device="cuda", requires_grad=True)
    outputs = net(x)
    require(isinstance(outputs, (list, tuple)) and len(outputs) == 3, "Deep supervision output count differs")
    scales = tr.deep_supervision_scales
    expected = [(2, 4) + tuple(int(round(int(n) * float(s))) for n, s in zip(tr.patch_size, scale)) for scale in scales]
    require([tuple(y.shape) for y in outputs] == expected, "Output shapes differ from independent trainer supervision scales")
    require(all(torch.isfinite(y).all().item() for y in outputs), "Nonfinite model output")
    targets = [torch.randint(0, 4, (2, 1) + shape[2:], device="cuda").float() for shape in expected]
    loss = tr.loss(outputs, targets)
    require(loss.numel() == 1 and loss.requires_grad and torch.isfinite(loss).item(), "Invalid real segmentation loss")
    loss.backward(); torch.cuda.synchronize()
    require(x.grad is not None and torch.isfinite(x.grad).all().item(), "Invalid input gradient")
    require(all(p.grad is None or torch.isfinite(p.grad).all().item() for p in net.parameters()), "Nonfinite parameter gradient")
    gradient_counts = {}
    for name, module in components.items():
        require(calls[name] > 0, "A retained/identity component did not run: " + name)
        if name.startswith("IdentityFFN"):
            continue
        gradients = [p.grad for p in module.parameters() if p.grad is not None]
        require(gradients and any(torch.count_nonzero(g).item() > 0 for g in gradients), "Missing active component gradient: " + name)
        gradient_counts[name] = len(gradients)
    for h in handles:
        h.remove()
    report = dict(status="REAL_NETWORK_FFN_PREFLIGHT_PASSED", seed=42, batch_size=2,
                  patch_size=[128, 128, 128], precision="FP32", output_shapes=expected,
                  optimizer_steps=0, optimizer_created=False, loss_kind="inherited actual segmentation loss; synthetic targets",
                  loss=float(loss.detach()), component_calls=calls, finite_gradient_counts=gradient_counts,
                  architecture=tr.ffn_architecture_report,
                  seed_initialization=tr.ffn_seed_audit,
                  peak_allocated_mib=torch.cuda.max_memory_allocated()/1024**2,
                  gpu=torch.cuda.get_device_name(0), torch_version=torch.__version__, numpy_version=np.__version__)
    unchanged(manifest["source_sha256"])
    with (run_folder / "gpu_preflight.json").open("x") as f:
        json.dump(report, f, indent=2)
    print("REAL_NETWORK_FFN_PREFLIGHT_PASSED; OPTIMIZER_STEPS=0", flush=True)
    print("PRESERVED_COMPONENT_CALLS=" + repr(calls), flush=True)


def write_exit(run_folder, code):
    with (run_folder / "training.exit").open("x") as f:
        f.write(str(code) + "\n")


def worker(run_folder):
    manifest = json.loads((run_folder / "input_audit.json").read_text())
    nonce = manifest["launch_nonce"]
    lock = ROOT / "run_logs/tumor_wo_ffn_seed42.launch.lock"
    require(lock.read_text().strip() == nonce, "Launch lock does not match")
    code = 1
    try:
        unchanged(manifest["source_sha256"])
        require((run_folder / "cpu_tests.exit").read_text().strip() == "0", "CPU tests not passed")
        probe = json.loads((run_folder / "gpu_preflight.json").read_text())
        require(probe["status"] == "REAL_NETWORK_FFN_PREFLIGHT_PASSED", "GPU preflight not passed")
        out = ROOT / OUT_REL
        unused_output_tree(out)
        tr = construct()
        require(not tr.was_initialized and getattr(tr, "network", None) is None, "Not a fresh trainer")
        tr.initialize(training=True)
        import torch
        require(torch.initial_seed() == 42 and torch.cuda.initial_seed() == 42,
                "CPU/CUDA initial seed changed during model initialization")
        require(tr.epoch == 0, "Training must begin at epoch0")
        tr.run_training()
        unchanged(manifest["source_sha256"])
        require((Path(tr.output_folder) / "model_final_checkpoint.model").is_file(), "Final checkpoint missing")
        code = 0
        print("TUMOR_WO_FFN_SEED42_TRAINING_FINISHED", flush=True)
    finally:
        write_exit(run_folder, code)
        if lock.is_file() and lock.read_text().strip() == nonce:
            lock.unlink()


def launch():
    require(shutil.which("screen") is not None, "screen is not installed")
    manifest = audit()
    idle_gpu()
    listing = subprocess.run(["screen", "-ls"], capture_output=True, text=True)
    require("." + SESSION not in listing.stdout, "Training screen session already exists")
    logs = ROOT / "run_logs"
    logs.mkdir(exist_ok=True)
    nonce = uuid.uuid4().hex
    lock = logs / "tumor_wo_ffn_seed42.launch.lock"
    with lock.open("x") as f:
        f.write(nonce + "\n")
    manifest["launch_nonce"] = nonce
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_UTC_") + nonce[:8]
    run_folder = logs / ("tumor_wo_ffn_seed42_" + stamp)
    run_folder.mkdir()
    transferred = False
    try:
        with (run_folder / "input_audit.json").open("x") as f:
            json.dump(manifest, f, indent=2)
        cpu_env = environment(); cpu_env["CUDA_VISIBLE_DEVICES"] = ""
        with (run_folder / "cpu_tests.log").open("x") as f:
            p = subprocess.run([sys.executable, str(HERE / "test_ffn_identity_cpu.py")],
                               cwd=HERE, env=cpu_env, stdout=f, stderr=subprocess.STDOUT)
        with (run_folder / "cpu_tests.exit").open("x") as f:
            f.write(str(p.returncode) + "\n")
        if p.returncode:
            print("\n".join((run_folder / "cpu_tests.log").read_text(errors="replace").splitlines()[-60:]), flush=True)
        require(p.returncode == 0, "CPU tests failed/skipped; see " + str(run_folder / "cpu_tests.log"))
        print("FFN_CPU_TESTS_PASSED", flush=True)
        with (run_folder / "gpu_preflight.log").open("x") as f:
            p = subprocess.run([sys.executable, "-u", str(Path(__file__).resolve()), "--gpu-preflight", str(run_folder)],
                               cwd=HERE, env=environment(True, run_folder / "probe_results"), stdout=f, stderr=subprocess.STDOUT)
        if p.returncode:
            print("\n".join((run_folder / "gpu_preflight.log").read_text(errors="replace").splitlines()[-70:]), flush=True)
        require(p.returncode == 0, "GPU/seed/reference check failed; see " + str(run_folder / "gpu_preflight.log"))
        require(json.loads((run_folder / "gpu_preflight.json").read_text())["status"] == "REAL_NETWORK_FFN_PREFLIGHT_PASSED", "GPU report not passed")
        print("REAL_NETWORK_FFN_PREFLIGHT_PASSED; formal training rebuilds seed42", flush=True)
        unchanged(manifest["source_sha256"])
        idle_gpu()
        ROOT.joinpath(OUT_REL).mkdir(parents=True, exist_ok=True)
        log = run_folder / "dispatch.log"
        with log.open("x") as f:
            subprocess.run(["screen", "-L", "-Logfile", str(run_folder / "screen.log"), "-dmS", SESSION,
                            sys.executable, "-u", str(Path(__file__).resolve()), "--worker", str(run_folder)],
                           cwd=HERE, env=environment(), stdout=f, stderr=subprocess.STDOUT, check=True)
        transferred = True
        print("SCREEN_DISPATCHED=" + SESSION, flush=True)
        print("TRAINING_LOG=" + str(run_folder / "screen.log"), flush=True)
        print("EXIT_FILE=" + str(run_folder / "training.exit"), flush=True)
        print("OUTPUT=" + str(ROOT / OUT_REL), flush=True)
        print("Background dispatch alone is not training confirmation; check epoch0 in the log.", flush=True)
    finally:
        if not transferred and lock.is_file() and lock.read_text().strip() == nonce:
            lock.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--gpu-preflight", type=Path, help=argparse.SUPPRESS)
    mode.add_argument("--worker", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.gpu_preflight:
        gpu_probe(args.gpu_preflight)
    elif args.worker:
        worker(args.worker)
    elif args.run:
        launch()
    else:
        audit()
        print("READ_ONLY_AUDIT_PASSED; TRAINING_NOT_STARTED. Add --run for guarded preflight + launch.")


if __name__ == "__main__":
    main()
