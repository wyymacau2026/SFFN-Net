"""CPU fixtures for the four-site FFN transform, not full SFFN-Net validation.

The fixtures use real CPU PyTorch tensors and autograd when available, but
their projections and DASI are deliberately small synthetic modules. Source
verification is mocked: these tests do not verify the audited project's class
paths, hashes, actual network, data, checkpoints, GPU support or training
protocol. No optimizer is created or stepped, and no training is launched.

Run this file directly for an honest status: exit 0 means all fixture tests
passed; exit 1 means failure/error; exit 2 means INCOMPLETE because at least
one test was skipped. The two early caller guards run even without PyTorch.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
import unittest
from unittest import mock


TOOL_PATH = Path(__file__).with_name("ffn_identity.py")
TOOL_SPEC = importlib.util.spec_from_file_location("ffn_identity_cpu_fixture_target", TOOL_PATH)
if TOOL_SPEC is None or TOOL_SPEC.loader is None:
    raise RuntimeError(f"Cannot load the local FFN tool: {TOOL_PATH}")
ffn_identity = importlib.util.module_from_spec(TOOL_SPEC)
sys.modules[TOOL_SPEC.name] = ffn_identity
TOOL_SPEC.loader.exec_module(ffn_identity)

try:
    import torch
    from torch import nn
    from torch.nn import functional as F
except ModuleNotFoundError as exc:
    if exc.name != "torch":
        raise
    torch = None
    nn = None
    F = None


TORCH_AVAILABLE = torch is not None
SKIP_REASON = "PyTorch is not installed; real CPU fixture checks were not run."
TARGETS = tuple(f"unetr_pp_encoder.FCA{stage}.FFN" for stage in range(4))
FIXTURE_PROJECT = Path(__file__).parent / "nonexistent_fixture_project"


def _within_target(name):
    return any(name == target or name.startswith(target + ".") for target in TARGETS)


if TORCH_AVAILABLE:
    class _Projection2d(nn.Module):
        def __init__(self, channels, gain=1.0):
            super().__init__()
            self.projection = nn.Conv2d(channels, channels, 1, bias=False)
            self.register_buffer("offset", torch.tensor(0.25, device="cpu"))
            self.forward_calls = 0
            with torch.no_grad():
                self.projection.weight.zero_()
                for channel in range(channels):
                    self.projection.weight[channel, channel, 0, 0] = gain

        def forward(self, value):
            self.forward_calls += 1
            return self.projection(value) + self.offset


    class MultiFrequencyChannelAttention(_Projection2d):
        pass


    class MixAttention(_Projection2d):
        pass


    class MixAttention2(_Projection2d):
        pass


    class SS2D(_Projection2d):
        pass


    class Mix(_Projection2d):
        pass


    class PSA_s(_Projection2d):
        pass


    class DASI(nn.Module):
        """Synthetic differentiable fixture; not the original DASI forward."""

        def __init__(self, channels):
            super().__init__()
            self.projection = nn.Conv3d(channels, channels, 1, bias=False)
            self.register_buffer("offset", torch.tensor(0.5, device="cpu"))
            with torch.no_grad():
                self.projection.weight.zero_()
                for channel in range(channels):
                    self.projection.weight[channel, channel, 0, 0, 0] = 1

        def forward(self, current, low, high):
            result = self.projection(current) + self.offset
            for neighbor in (low, high):
                if neighbor is not None:
                    aligned = F.interpolate(neighbor.mean(dim=1, keepdim=True),
                                            size=current.shape[2:],
                                            mode="trilinear", align_corners=True)
                    result = result + aligned / 8
            return result


    class FCA(nn.Module):
        def __init__(self, channels):
            super().__init__()
            self.Fre = MultiFrequencyChannelAttention(channels)
            self.DASI = DASI(channels)
            self.FFN = MixAttention(channels, gain=2.0)

        def forward(self, value, low, high):
            batch, channels, height, width, depth = value.shape
            value = value.view(batch, channels, height, width * depth)
            value = self.Fre(value)
            value = value.view(batch, channels, height, width, depth)
            value = self.DASI(value, low, high)
            value = value.view(batch, channels, height, width * depth)
            value = self.FFN(value)
            return value.view(batch, channels, height, width, depth)


    class FCA2(FCA):
        def __init__(self, channels):
            super().__init__(channels)
            self.FFN = MixAttention2(channels, gain=3.0)


    class TransformerBlock(nn.Module):
        def __init__(self, channels):
            super().__init__()
            # A same-class non-target proves that replacement is path-scoped.
            self.mlp = MixAttention(channels, gain=4.0)
            self.norm = nn.BatchNorm2d(channels)


    class MSSBlock(nn.Module):
        def __init__(self, channels):
            super().__init__()
            self.ssm_branch = True
            self.mlp_branch = True
            self.proj_conv = nn.Sequential(
                nn.Conv2d(channels, channels, 1), nn.BatchNorm2d(channels), nn.SiLU())
            self.norm = nn.BatchNorm2d(channels)
            self.op = SS2D(channels)
            self.lsblock = Mix(channels)
            self.norm2 = nn.BatchNorm2d(channels)
            self.mlp = PSA_s(channels)
            self.drop_path = nn.Identity()


    class UnetrPPEncoder(nn.Module):
        def __init__(self, reference_class):
            super().__init__()
            channels = (4, 8, 12, 16)
            self.MSS_en = True
            self.FCA_en = reference_class == "FCA"
            self.FCA2_en = True
            self.stages = nn.ModuleList(
                nn.Sequential(TransformerBlock(count)) for count in channels)
            self.MSS = MSSBlock(channels[0])
            fca_type = {"FCA": FCA, "FCA2": FCA2}[reference_class]
            for stage, count in enumerate(channels):
                self.add_module(f"FCA{stage}", fca_type(count))


    class UNETR_PP(nn.Module):
        def __init__(self, reference_class):
            super().__init__()
            self.unetr_pp_encoder = UnetrPPEncoder(reference_class)
            self.output_projection = nn.Conv3d(4, 2, 1)
            self.cpu().eval()


class FFNIdentityEarlyGuardTests(unittest.TestCase):
    """These guards must execute before the lazy PyTorch import or source read."""

    def test_rejects_existing_optimizer_without_reading_source(self):
        with mock.patch.object(ffn_identity, "_verify_source") as source_check:
            with self.assertRaisesRegex(ffn_identity.AblationAuditError, "optimizer"):
                ffn_identity.apply_ffn_identity(
                    object(), optimizer=object(), expected_fca_class="FCA",
                    project_root=FIXTURE_PROJECT)
            source_check.assert_not_called()

    def test_rejects_unknown_reference_without_reading_source(self):
        with mock.patch.object(ffn_identity, "_verify_source") as source_check:
            with self.assertRaisesRegex(ffn_identity.AblationAuditError, "FCA"):
                ffn_identity.apply_ffn_identity(
                    object(), optimizer=None, expected_fca_class="unverified",
                    project_root=FIXTURE_PROJECT)
            source_check.assert_not_called()


@unittest.skipUnless(TORCH_AVAILABLE, SKIP_REASON)
class FFNIdentityCPUFixtureTests(unittest.TestCase):
    """Source checks are mocked; only CPU transform mechanics are validated."""

    def setUp(self):
        self.source_patch = mock.patch.object(
            ffn_identity, "_verify_source", return_value="MOCKED_FIXTURE_NOT_A_SOURCE_HASH")
        self.source_check = self.source_patch.start()
        self.addCleanup(self.source_patch.stop)

    def _network(self, reference_class="FCA"):
        return UNETR_PP(reference_class)

    def _apply(self, network, reference_class="FCA"):
        return ffn_identity.apply_ffn_identity(
            network, optimizer=None, expected_fca_class=reference_class,
            project_root=FIXTURE_PROJECT)

    def _targets(self, network):
        return [getattr(network.unetr_pp_encoder, f"FCA{stage}") for stage in range(4)]

    def _snapshot(self, network, *, protected_only=False):
        snapshot = {}
        for kind, values in (
            ("parameter", network.named_parameters(remove_duplicate=False)),
            ("buffer", network.named_buffers(remove_duplicate=False)),
        ):
            for name, value in values:
                if protected_only and _within_target(name):
                    continue
                snapshot[(kind, name)] = (id(value), value.detach().clone(), value.requires_grad)
        return snapshot

    def _assert_snapshot_equal(self, network, expected, *, protected_only=False):
        actual = self._snapshot(network, protected_only=protected_only)
        self.assertEqual(set(actual), set(expected))
        for key, (identity, tensor, requires_grad) in expected.items():
            with self.subTest(registration=key):
                actual_identity, actual_tensor, actual_requires_grad = actual[key]
                self.assertEqual(actual_identity, identity)
                self.assertEqual(actual_requires_grad, requires_grad)
                self.assertEqual(actual_tensor.device.type, "cpu")
                torch.testing.assert_close(actual_tensor, tensor, rtol=0, atol=0)

    def _inputs(self, *, requires_grad=False):
        return [torch.full((2, channels, 2, 3, 4), float(stage + 1),
                           dtype=torch.float32, device="cpu", requires_grad=requires_grad)
                for stage, channels in enumerate((4, 8, 12, 16))]

    def test_both_reference_classes_replace_exactly_four_targets_and_preserve_modes(self):
        for reference_class in ("FCA", "FCA2"):
            with self.subTest(reference_class=reference_class):
                network = self._network(reference_class)
                fcas = self._targets(network)
                original_type = MixAttention if reference_class == "FCA" else MixAttention2
                for stage, fca in enumerate(fcas):
                    self.assertIs(type(fca.FFN), original_type)
                    fca.FFN.train(stage % 2 == 0)
                modes = [fca.FFN.training for fca in fcas]
                report = self._apply(network, reference_class)
                for stage, fca in enumerate(fcas):
                    self.assertIs(type(fca.FFN), nn.Identity)
                    self.assertIs(fca.FFN.training, modes[stage])
                self.assertEqual(report["targets"], list(TARGETS))
                self.assertEqual(report["original_ffn_class"], original_type.__name__)
                self.assertIs(report["forward_and_training_preflight_complete"], False)
                # The source check is a fixture mock, never a verified digest.
                self.assertTrue(self.source_check.called)

    def test_preserves_all_non_target_modules_and_tensor_values(self):
        for reference_class in ("FCA", "FCA2"):
            with self.subTest(reference_class=reference_class):
                network = self._network(reference_class)
                network.unetr_pp_encoder.MSS.norm.train(True)
                for stage, fca in enumerate(self._targets(network)):
                    fca.Fre.train(stage % 2 == 0)
                modules = {name: module for name, module in network.named_modules(remove_duplicate=False)
                           if not _within_target(name)}
                modes = {name: module.training for name, module in modules.items()}
                snapshot = self._snapshot(network, protected_only=True)
                self._apply(network, reference_class)
                actual_modules = dict(network.named_modules(remove_duplicate=False))
                for name, module in modules.items():
                    self.assertIs(actual_modules[name], module)
                    self.assertIs(actual_modules[name].training, modes[name])
                self._assert_snapshot_equal(network, snapshot, protected_only=True)
                encoder = network.unetr_pp_encoder
                self.assertIs(type(encoder.MSS.mlp), PSA_s)
                self.assertIs(type(encoder.MSS.op), SS2D)
                self.assertIs(type(encoder.MSS.lsblock), Mix)
                self.assertIs(type(encoder.stages[0][0].mlp), MixAttention)

    def test_removes_target_parameters_buffers_and_state_dict_keys_only(self):
        for reference_class in ("FCA", "FCA2"):
            with self.subTest(reference_class=reference_class):
                network = self._network(reference_class)
                removed_ids = {id(value) for fca in self._targets(network)
                               for value in list(fca.FFN.parameters()) + list(fca.FFN.buffers())}
                state_keys = set(network.state_dict())
                expected_keys = {name for name in state_keys if not _within_target(name)}
                self.assertLess(len(expected_keys), len(state_keys))
                self._apply(network, reference_class)
                self.assertEqual(set(network.state_dict()), expected_keys)
                after_ids = {id(value) for value in list(network.parameters()) + list(network.buffers())}
                self.assertTrue(after_ids.isdisjoint(removed_ids))
                for fca in self._targets(network):
                    self.assertEqual(list(fca.FFN.parameters()), [])
                    self.assertEqual(list(fca.FFN.buffers()), [])

    def test_fca_outputs_are_the_preserved_dasi_output_with_original_reshapes(self):
        for reference_class in ("FCA", "FCA2"):
            with self.subTest(reference_class=reference_class):
                network = self._network(reference_class)
                originals = [fca.FFN for fca in self._targets(network)]
                self._apply(network, reference_class)
                inputs = self._inputs()
                for stage, fca in enumerate(self._targets(network)):
                    dasi_outputs = []
                    identity_input_shapes = []
                    dasi_hook = fca.DASI.register_forward_hook(
                        lambda module, args, output: dasi_outputs.append(output.detach().clone()))
                    identity_hook = fca.FFN.register_forward_pre_hook(
                        lambda module, args: identity_input_shapes.append(tuple(args[0].shape)))
                    try:
                        output = fca(inputs[stage], inputs[stage + 1] if stage < 3 else None,
                                     inputs[stage - 1] if stage > 0 else None)
                    finally:
                        identity_hook.remove()
                        dasi_hook.remove()
                    self.assertEqual(tuple(output.shape), tuple(inputs[stage].shape))
                    self.assertEqual(output.device.type, "cpu")
                    self.assertTrue(torch.isfinite(output).all().item())
                    self.assertEqual(identity_input_shapes,
                                     [(2, inputs[stage].shape[1], 2, 12)])
                    self.assertEqual(len(dasi_outputs), 1)
                    torch.testing.assert_close(output, dasi_outputs[0], rtol=0, atol=0)
                    self.assertEqual(originals[stage].forward_calls, 0)

    def test_backward_reaches_preserved_fre_dasi_and_inputs_for_both_classes(self):
        for reference_class in ("FCA", "FCA2"):
            with self.subTest(reference_class=reference_class):
                network = self._network(reference_class)
                self._apply(network, reference_class)
                inputs = self._inputs(requires_grad=True)
                outputs = [fca(inputs[stage], inputs[stage + 1] if stage < 3 else None,
                               inputs[stage - 1] if stage > 0 else None)
                           for stage, fca in enumerate(self._targets(network))]
                loss = sum(output.square().mean() for output in outputs)
                self.assertTrue(torch.isfinite(loss).item())
                loss.backward()
                for stage, fca in enumerate(self._targets(network)):
                    for component in (fca.Fre, fca.DASI):
                        gradient = component.projection.weight.grad
                        self.assertIsNotNone(gradient)
                        self.assertEqual(gradient.device.type, "cpu")
                        self.assertTrue(torch.isfinite(gradient).all().item())
                        self.assertGreater(gradient.abs().sum().item(), 0)
                    self.assertIsNotNone(inputs[stage].grad)
                    self.assertTrue(torch.isfinite(inputs[stage].grad).all().item())
                    self.assertGreater(inputs[stage].grad.abs().sum().item(), 0)
                for parameter in network.parameters():
                    if parameter.grad is not None:
                        self.assertTrue(torch.isfinite(parameter.grad).all().item())

    def test_rejects_already_applied_transform_without_changing_identities(self):
        network = self._network()
        self._apply(network)
        identities = [fca.FFN for fca in self._targets(network)]
        with self.assertRaises(ffn_identity.AblationAuditError):
            self._apply(network)
        self.assertEqual([id(fca.FFN) for fca in self._targets(network)],
                         [id(module) for module in identities])

    def test_rejects_stacking_with_each_other_component_replaced(self):
        mutations = (
            ("SS2D", lambda net: setattr(net.unetr_pp_encoder.MSS, "op", nn.Identity())),
            ("MSPLCK", lambda net: setattr(net.unetr_pp_encoder.MSS, "lsblock", nn.Identity())),
            ("PSA", lambda net: setattr(net.unetr_pp_encoder.MSS, "mlp", nn.Identity())),
            ("MFCA", lambda net: setattr(net.unetr_pp_encoder.FCA0, "Fre", nn.Identity())),
            ("DASI", lambda net: setattr(net.unetr_pp_encoder.FCA0, "DASI", nn.Identity())),
        )
        for name, mutate in mutations:
            with self.subTest(component=name):
                network = self._network()
                mutate(network)
                originals = [fca.FFN for fca in self._targets(network)]
                with self.assertRaises(ffn_identity.AblationAuditError):
                    self._apply(network)
                self.assertEqual([id(fca.FFN) for fca in self._targets(network)],
                                 [id(module) for module in originals])

    def test_rejects_wrong_reference_flags_without_mutation(self):
        network = self._network("FCA")
        network.unetr_pp_encoder.FCA_en = False
        originals = [fca.FFN for fca in self._targets(network)]
        with self.assertRaises(ffn_identity.AblationAuditError):
            self._apply(network, "FCA")
        self.assertEqual([id(fca.FFN) for fca in self._targets(network)],
                         [id(module) for module in originals])

    def test_rejects_target_module_alias(self):
        network = self._network()
        original = network.unetr_pp_encoder.FCA0.FFN
        network.unetr_pp_encoder.target_alias = original
        with self.assertRaises(ffn_identity.AblationAuditError):
            self._apply(network)
        self.assertIs(network.unetr_pp_encoder.FCA0.FFN, original)
        self.assertIs(network.unetr_pp_encoder.target_alias, original)

    def test_rejects_target_tensor_shared_with_preserved_component(self):
        for tensor_kind in ("parameter", "buffer"):
            with self.subTest(tensor_kind=tensor_kind):
                network = self._network()
                fca = network.unetr_pp_encoder.FCA0
                if tensor_kind == "parameter":
                    fca.Fre.projection.weight = fca.FFN.projection.weight
                else:
                    fca.Fre.offset = fca.FFN.offset
                originals = [item.FFN for item in self._targets(network)]
                snapshot = self._snapshot(network)
                with self.assertRaises(ffn_identity.AblationAuditError):
                    self._apply(network)
                self.assertEqual([id(item.FFN) for item in self._targets(network)],
                                 [id(module) for module in originals])
                self._assert_snapshot_equal(network, snapshot)

    def test_rejects_target_hooks_instead_of_silently_discarding_them(self):
        for hook_kind in (
            "forward", "full_backward_pre", "_state_dict_hooks", "_state_dict_pre_hooks",
            "_load_state_dict_pre_hooks", "_load_state_dict_post_hooks",
        ):
            with self.subTest(hook_kind=hook_kind):
                network = self._network()
                original = network.unetr_pp_encoder.FCA0.FFN
                handle = None
                hook_registry = None
                registry_key = object()
                if hook_kind == "forward":
                    handle = original.register_forward_hook(lambda module, args, output: None)
                elif hook_kind == "full_backward_pre":
                    handle = original.register_full_backward_pre_hook(
                        lambda module, grad_output: None)
                else:
                    # Register a sentinel without invoking any state operation;
                    # the transform must reject it before state_dict() is used.
                    hook_registry = getattr(original, hook_kind, None)
                    if hook_registry is None:
                        hook_registry = {}
                        setattr(original, hook_kind, hook_registry)
                    hook_registry[registry_key] = lambda *args, **kwargs: None
                try:
                    with self.assertRaises(ffn_identity.AblationAuditError):
                        self._apply(network)
                    self.assertIs(network.unetr_pp_encoder.FCA0.FFN, original)
                finally:
                    if handle is not None:
                        handle.remove()
                    elif hook_registry is not None:
                        hook_registry.pop(registry_key, None)

    def test_failed_postcheck_restores_all_four_original_targets_and_state(self):
        network = self._network()
        originals = [fca.FFN for fca in self._targets(network)]
        snapshot = self._snapshot(network)
        original_state_dict = network.state_dict
        state_keys = set(original_state_dict())
        calls = []

        def corrupted_postcheck(*args, **kwargs):
            state = original_state_dict(*args, **kwargs)
            calls.append(1)
            if len(calls) == 2:
                # The failure is injected only after all four replacements.
                self.assertTrue(all(type(fca.FFN) is nn.Identity
                                    for fca in self._targets(network)))
                state["fixture_injected_postcheck_key"] = torch.tensor(0.0, device="cpu")
            return state

        with mock.patch.object(network, "state_dict", side_effect=corrupted_postcheck):
            with self.assertRaises(ffn_identity.AblationAuditError):
                self._apply(network)
        self.assertGreaterEqual(len(calls), 2)
        self.assertEqual([id(fca.FFN) for fca in self._targets(network)],
                         [id(module) for module in originals])
        self.assertEqual(set(network.state_dict()), state_keys)
        self._assert_snapshot_equal(network, snapshot)


@unittest.skipUnless(TORCH_AVAILABLE, SKIP_REASON)
class FFNDiagnosticCPUFixtureTests(unittest.TestCase):
    """Exercise the optional diagnostic on disposable toy CPU networks only."""

    def _network(self):
        network = nn.Sequential(nn.Conv3d(1, 2, 1, bias=False)).cpu()
        with torch.no_grad():
            network[0].weight.fill_(1)
        return network

    def _check(self, network, *, loss_builder=None, expected_output_shapes=None):
        example = torch.ones((1, 1, 4, 4, 4), dtype=torch.float32, device="cpu")
        return ffn_identity.check_model_forward_backward(
            network, example, optimizer=None, disposable_model=True,
            expected_output_shapes=expected_output_shapes or [(1, 2, 4, 4, 4)],
            required_gradient_names=["0.weight"], loss_builder=loss_builder)

    def test_single_tensor_diagnostic_produces_gradients_without_changing_weights(self):
        network = self._network()
        original = network[0].weight.detach().clone()
        report = self._check(network)
        self.assertEqual(report["device"], "cpu")
        self.assertEqual(report["output_shapes"], [(1, 2, 4, 4, 4)])
        self.assertEqual(report["loss_kind"], "synthetic_connectivity_probe")
        self.assertEqual(report["optimizer_steps"], 0)
        self.assertIs(report["training_protocol_preflight_complete"], False)
        self.assertIs(report["rebuild_from_original_seed_before_training"], True)
        self.assertIsNotNone(network[0].weight.grad)
        self.assertTrue(torch.isfinite(network[0].weight.grad).all().item())
        self.assertGreater(network[0].weight.grad.abs().sum().item(), 0)
        torch.testing.assert_close(network[0].weight.detach(), original, rtol=0, atol=0)

    def test_deep_supervision_tuple_is_passed_intact_to_caller_loss(self):
        class ToyDeepSupervision(nn.Sequential):
            def forward(self, example):
                full = super().forward(example)
                return full, F.avg_pool3d(full, kernel_size=2)

        base = self._network()
        network = ToyDeepSupervision(base[0])
        seen = []

        def criterion(raw_outputs):
            self.assertIsInstance(raw_outputs, tuple)
            self.assertEqual(len(raw_outputs), 2)
            seen.append(raw_outputs)
            return sum(output.square().mean() for output in raw_outputs)

        report = self._check(
            network, loss_builder=criterion,
            expected_output_shapes=[(1, 2, 4, 4, 4), (1, 2, 2, 2, 2)])
        self.assertEqual(len(seen), 1)
        self.assertEqual(report["loss_kind"], "caller_supplied")
        self.assertEqual(report["output_shapes"], [(1, 2, 4, 4, 4), (1, 2, 2, 2, 2)])
        self.assertEqual(report["optimizer_steps"], 0)

    def test_required_parameter_with_zero_gradient_is_rejected(self):
        network = self._network()
        with self.assertRaisesRegex(ffn_identity.AblationAuditError, "nonzero gradient"):
            self._check(network, loss_builder=lambda outputs: outputs.sum() * 0)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        print("FAILED: FFN fixture checks reported failures/errors.", file=sys.stderr)
        raise SystemExit(1)
    if not TORCH_AVAILABLE or result.skipped or result.testsRun == 0:
        print(f"INCOMPLETE: {len(result.skipped)} CPU fixture tests were skipped; "
              "missing PyTorch/skipped/empty tests are not an all-pass result.", file=sys.stderr)
        raise SystemExit(2)
    print("PASS: CPU fixture mechanics only; complete SFFN-Net validation remains pending.")
    raise SystemExit(0)
