"""Standard-library launcher checks; no PyTorch/CUDA/network required."""
import ast
import contextlib
import importlib.util
import io
import json
import os
import pickle
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location("ffn_launcher", Path(__file__).with_name("run_tumor_wo_ffn_seed42.py"))
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)


class Guards(unittest.TestCase):
    def fake_torch(self):
        module = SimpleNamespace(cpu_seed=12345, cuda_seed=12345)
        module.manual_seed = lambda seed: setattr(module, "cpu_seed", seed)
        module.initial_seed = lambda: module.cpu_seed
        module.cuda = SimpleNamespace(manual_seed_all=lambda seed: setattr(module, "cuda_seed", seed))
        return module

    def fresh_trainer(self):
        return SimpleNamespace(was_initialized=False, network=None, optimizer=None, tr_gen=None, val_gen=None)

    def test_parent_12345_reset_is_corrected_to_42_before_network(self):
        import numpy as np
        np_state, py_state = np.random.get_state(), mod.random.getstate()
        self.addCleanup(np.random.set_state, np_state)
        self.addCleanup(mod.random.setstate, py_state)
        np.random.seed(12345); mod.random.seed(12345)
        torch = self.fake_torch()
        tr = self.fresh_trainer()
        with patch.dict(os.environ, {"EXPERIMENT_SEED": "42", "PYTHONHASHSEED": "42"}):
            receipt = mod.reset_seed_after_constructor(tr, np, torch)
        self.assertEqual((torch.cpu_seed, torch.cuda_seed), (42, 42))
        self.assertTrue(np.array_equal(np.random.get_state()[1], np.random.RandomState(42).get_state()[1]))
        self.assertEqual(mod.random.getstate(), mod.random.Random(42).getstate())
        self.assertEqual(receipt["effective_seed"], 42)
        self.assertIs(tr.network, None)
        self.assertIs(tr.optimizer, None)
        self.assertIs(tr.ffn_seed_audit, receipt)

    def test_reseed_refuses_initialized_model_optimizer_or_generators(self):
        import numpy as np
        with patch.dict(os.environ, {"EXPERIMENT_SEED": "42", "PYTHONHASHSEED": "42"}):
            for field, value in (("was_initialized", True), ("network", object()),
                                 ("optimizer", object()), ("tr_gen", object()), ("val_gen", object())):
                tr = self.fresh_trainer()
                setattr(tr, field, value)
                with self.subTest(field=field), self.assertRaises(RuntimeError):
                    mod.reset_seed_after_constructor(tr, np, self.fake_torch())

    def test_wrong_environment_seed_is_not_silently_corrected(self):
        import numpy as np
        with patch.dict(os.environ, {"EXPERIMENT_SEED": "43", "PYTHONHASHSEED": "42"}):
            with self.assertRaisesRegex(RuntimeError, "process startup"):
                mod.reset_seed_after_constructor(self.fresh_trainer(), np, self.fake_torch())

    def test_fresh_probe_and_training_reseed_reproduce_starting_streams(self):
        import numpy as np
        np_state, py_state = np.random.get_state(), mod.random.getstate()
        self.addCleanup(np.random.set_state, np_state)
        self.addCleanup(mod.random.setstate, py_state)
        sequences = []
        with patch.dict(os.environ, {"EXPERIMENT_SEED": "42", "PYTHONHASHSEED": "42"}):
            for _ in range(2):
                np.random.seed(12345); mod.random.seed(12345)
                mod.reset_seed_after_constructor(self.fresh_trainer(), np, self.fake_torch())
                sequences.append((list(np.random.random(5)), [mod.random.random() for _ in range(5)]))
        self.assertEqual(sequences[0], sequences[1])

    def test_construct_uses_reference_determinism_and_reseeds_after_parent(self):
        text = Path(__file__).with_name("run_tumor_wo_ffn_seed42.py").read_text(encoding="utf-8")
        tree = ast.parse(text)
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "construct")
        body = ast.get_source_segment(text, node)
        self.assertIn('reference_deterministic = literal(ref["deterministic"])', body)
        self.assertIn("deterministic=reference_deterministic", body)
        self.assertLess(body.index("tr = unetr_pp_trainer_tumor_wo_ffn("), body.index("reset_seed_after_constructor(tr, np, torch)"))
        self.assertIn('last.get(label) == 42', body)

    def test_config_three_true_and_duplicate_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            p = Path(t) / "config.yaml"
            p.write_text("MSS_en: true\nFCA_en: True\nFCA2_en: true # note\n")
            self.assertEqual(mod.flags(p), dict(MSS_en="true", FCA_en="true", FCA2_en="true"))
            p.write_text("MSS_en: true\nMSS_en: false\n")
            with self.assertRaisesRegex(RuntimeError, "Duplicate"):
                mod.flags(p)

    def test_literal_debug_values(self):
        self.assertEqual(mod.literal("300"), 300)
        self.assertEqual(mod.literal("0.01"), .01)
        self.assertIs(mod.literal("False"), False)
        self.assertEqual(mod.literal("not-a-literal"), "not-a-literal")

    def test_gpu_busy_is_rejected(self):
        with patch.object(mod.shutil, "which", return_value="nvidia-smi"), patch.object(mod.subprocess, "run", return_value=SimpleNamespace(stdout="1234\n")):
            with self.assertRaisesRegex(RuntimeError, "compute processes"):
                mod.idle_gpu()

    def test_gpu_idle_accepted(self):
        with patch.object(mod.shutil, "which", return_value="nvidia-smi"), patch.object(mod.subprocess, "run", return_value=SimpleNamespace(stdout="")):
            mod.idle_gpu()

    def test_child_seed_and_config_environment(self):
        with patch.dict(os.environ, {"FFN_DISPOSABLE_PREFLIGHT": "stale"}):
            e = mod.environment()
            self.assertNotIn("FFN_DISPOSABLE_PREFLIGHT", e)
            self.assertEqual(e["EXPERIMENT_SEED"], "42")
            self.assertEqual(e["PYTHONHASHSEED"], "42")
            self.assertTrue(e["RESULTS_FOLDER"].endswith("seed_42"))
            probe = mod.ROOT / "run_logs/probe_fixture/results"
            e = mod.environment(True, probe)
            self.assertEqual(e["FFN_DISPOSABLE_PREFLIGHT"], "1")
            self.assertEqual(e["RESULTS_FOLDER"], str(probe.absolute()))
            self.assertNotEqual(e["RESULTS_FOLDER"], str(mod.ROOT / mod.OUT_REL))

    def test_probe_cannot_default_to_formal_output(self):
        with self.assertRaisesRegex(RuntimeError, "separate RESULTS_FOLDER"):
            mod.environment(True)
        with self.assertRaisesRegex(RuntimeError, "inside run_logs"):
            mod.environment(True, mod.ROOT / mod.OUT_REL)

    def test_directory_only_output_skeleton_is_safe_and_preserved(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            out = Path(t) / "seed_42"
            self.assertEqual(mod.unused_output_tree(out), 0)
            (out / "unetr_pp/3d_fullres/Task003_tumor").mkdir(parents=True)
            self.assertEqual(mod.unused_output_tree(out), 3)
            self.assertTrue((out / "unetr_pp/3d_fullres/Task003_tumor").is_dir())

    def test_hidden_or_checkpoint_file_is_never_accepted(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            out = Path(t)
            nested = out / "unetr_pp/fold_0"
            nested.mkdir(parents=True)
            for name in ("model_best.model", ".hidden", "training.log"):
                p = nested / name
                p.write_text("preserve me")
                with self.subTest(name=name), self.assertRaisesRegex(RuntimeError, "no resume/overwrite"):
                    mod.unused_output_tree(out)
                self.assertEqual(p.read_text(), "preserve me")
                p.unlink()

    def test_symlinks_are_not_accepted_as_empty_directories(self):
        symbolic_root = SimpleNamespace(is_symlink=lambda: True)
        with self.assertRaisesRegex(RuntimeError, "symlink"):
            mod.unused_output_tree(symbolic_root)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            symbolic_child = SimpleNamespace(is_symlink=lambda: True, is_dir=lambda: True)
            with patch.object(type(Path(t)), "rglob", return_value=iter([symbolic_child])):
                with self.assertRaisesRegex(RuntimeError, "no resume/overwrite"):
                    mod.unused_output_tree(Path(t))

    def test_transform_between_parent_initialization_and_optimizer(self):
        text = Path(__file__).with_name("unetr_pp_trainer_tumor_wo_ffn.py").read_text(encoding="utf-8")
        tree = ast.parse(text)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef))
        names = {n.name for n in cls.body if isinstance(n, ast.FunctionDef)}
        self.assertNotIn("initialize_network", names)
        self.assertNotIn("__init__", names)
        node = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "initialize_optimizer_and_scheduler")
        body = ast.get_source_segment(text, node)
        self.assertLess(body.index("apply_ffn_identity("), body.index("super().initialize_optimizer_and_scheduler()"))
        self.assertNotIn("load_best_checkpoint", text)
        self.assertNotIn("load_checkpoint(", text)

    def test_probe_has_no_optimizer_update_or_source_copy(self):
        tree = ast.parse(Path(__file__).with_name("run_tumor_wo_ffn_seed42.py").read_text(encoding="utf-8"))
        probe = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "gpu_probe")
        names = [n.func.attr for n in ast.walk(probe) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)]
        self.assertNotIn("step", names)
        self.assertNotIn("copy", names)
        self.assertIn("backward", names)

    def fixture(self, root):
        package = root / "isolated_package"
        package.mkdir()
        for name in mod.PACKAGE_FILES:
            (package / name).write_text("# fixture\n")
        for path in (root / "config.yaml", package / "config.yaml"):
            path.write_text("MSS_en: true\nFCA_en: true\nFCA2_en: true\n")
        source_hashes = {}
        for rel in mod.SOURCE_SHA:
            p = root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("# original source fixture\n")
            source_hashes[rel] = mod.sha(p)
        task = root / mod.TASK_REL
        task.mkdir(parents=True)
        (task / "test_plans_3D.pkl").write_bytes(b"fixture")
        for rel in ("unetr_pp/run/default_configuration.py", "unetr_pp/paths.py", "unetr_pp/configuration.py"):
            p = root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("# configuration fixture\n")
        train, val = ([f"T{i}" for i in range(387)], [f"V{i}" for i in range(97)])
        sp = task / "splits_final.pkl"
        sp.write_bytes(pickle.dumps([dict(train=train, val=val)]))
        manifests = root / "experiment_manifests/tumor_fold0"
        manifests.mkdir(parents=True)
        for key, values in (("train", train), ("val", val)):
            (manifests / f"{key}_cases.txt").write_text("\n".join(values) + "\n", newline="\n")
        stage = task / "nnFormerData_plans_v2.1_stage0"
        stage.mkdir()
        gt = task / "gt_segmentations"
        gt.mkdir()
        for c in train + val:
            for ext in ("npz", "pkl", "npy"):
                (stage / f"{c}.{ext}").write_bytes(b"fixture")
            (gt / f"{c}.nii.gz").write_bytes(b"fixture")
        ref = root / "output_tumor_387_97/fold0/seed_42" / mod.FOLD_TAIL
        ref.mkdir(parents=True)
        (ref / "model_best.model").touch()
        (ref / "debug.json").write_text(json.dumps(dict(max_num_epochs="300", initial_lr="0.01", num_batches_per_epoch="250", num_val_batches_per_epoch="50", weight_decay="3e-5", fp16="False", deterministic="True")))
        (root / mod.OUT_REL).mkdir(parents=True)
        return package, source_hashes, mod.sha(sp)

    def test_audit_and_nonempty_output_and_hash_guards(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            root = Path(t)
            package, digests, split_sha = self.fixture(root)
            # Windows sandbox can deny realpath on newly created temp dirs.
            # Only fixture resolution is mocked; the delivered launcher keeps
            # strict realpath checks on the actual Linux server.
            with patch.object(type(root), "resolve", return_value=root), patch.object(mod, "ROOT", root), patch.object(mod, "HERE", package), patch.object(mod, "SOURCE_SHA", digests), patch.object(mod, "SPLIT_SHA", split_sha), patch.object(mod.platform, "node", return_value="autodl-container-a335-0b76b318"):
                with contextlib.redirect_stdout(io.StringIO()):
                    manifest = mod.audit()
                self.assertEqual(manifest["seed"], 42)
                mod.unchanged(manifest["source_sha256"])
                p = root / mod.OUT_REL / "existing.model"
                p.touch()
                with self.assertRaisesRegex(RuntimeError, "nonempty"):
                    mod.audit()
                p.unlink()
                first = root / next(iter(digests))
                first.write_text("changed")
                with self.assertRaisesRegex(RuntimeError, "SHA256 differs"):
                    mod.audit()


if __name__ == "__main__":
    unittest.main(verbosity=2)
