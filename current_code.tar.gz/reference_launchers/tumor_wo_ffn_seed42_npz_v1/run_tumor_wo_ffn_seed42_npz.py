#!/usr/bin/env python3
"""Best-checkpoint NPZ validation only: Tumor w/o four post-fusion FFNs, seed42.

Default is a CPU/file audit. --run dispatches a guarded GPU screen worker.
Rebuild the inherited complete network, apply exactly the trained four Identity
replacements before any optimizer creation, and strictly load best state tensors.
Validate in a NEW scratch tree and publish only after97-case export checks.
Original training architecture audit, checkpoint, source and configurations are
protected; no training, optimizer creation, checkpoint saving or source edits.
"""
from __future__ import annotations
import argparse
import inspect
import json
import hashlib
import math
import os
import pickle
import random
import re
import socket
import subprocess
import sys
import traceback
from collections import OrderedDict
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

ROOT = Path('/root/autodl-tmp/unetr_plus_plus-main')
TASK = ROOT / 'DATASET_Tumor/unetr_pp_raw/unetr_pp_raw_data/Task03_tumor/Task003_tumor'
OUTPUT = ROOT / 'output_tumor_ablation_387_97/w_o_ffn/fold0/seed_42'
FOLD = OUTPUT / 'unetr_pp/3d_fullres/Task003_tumor/unetr_pp_trainer_tumor__unetr_pp_Plansv2.1/fold_0'
TARGET = FOLD / 'validation_best_npz'
VERIFIED = FOLD / 'seed42_wo_ffn_npz_verified.json'
TRAIN_RUN = ROOT / 'run_logs/tumor_wo_ffn_seed42_20261016_050824_UTC_a0daf620'
HERE = Path(__file__).resolve().parent
SESSION = 'tumor_wo_ffn_s42_npz'
STATUS = 'TUMOR_WO_FFN_SEED42_NPZ_VERIFIED'
SPLIT_SHA = '3c747eff74412b5c60c02fc80754b11785342019c62ada2a63073191ea90517e'
HELPER_SHA = '0523b8d574e6ab42c036c1a574cff694c4dfaaf3337ce58f397629f0305a4dc4'
PARENT_SHA = 'e48dd1fd90198fa670f55aed55af24f2b22554283d90cca078cdc7c4fbdebb96'
TARGETS = [f'unetr_pp_encoder.FCA{i}.FFN' for i in range(4)]


def require(ok, message):
    if not ok:
        raise RuntimeError('STOP: ' + message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def new_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def unchanged(hashes):
    for path, digest in hashes.items():
        require(sha(path) == digest, 'Protected input changed: ' + path)


def flags(path):
    result = {}
    for raw in Path(path).read_text(encoding='utf-8-sig').splitlines():
        text = raw.split('#', 1)[0].strip()
        if text:
            key, value = text.split(':', 1)
            require(key.strip() not in result, 'Duplicate switch')
            result[key.strip()] = value.strip().lower()
    return result


def validate_split(split):
    train, val = (list(map(str, split[k])) for k in ('train', 'val'))
    require(len(train) == len(set(train)) == 387 and len(val) == len(set(val)) == 97,
            'Expected387/97 unique frozen cases')
    require(not set(train) & set(val), 'Train/validation overlap')
    return train, val


def completed_epochs(text):
    starts = list(re.finditer(r'\bepoch:\s*(\d+)\b', text, re.I))
    completed = {}
    for i, match in enumerate(starts):
        block = text[match.end():starts[i + 1].start() if i + 1 < len(starts) else len(text)]
        times = re.findall(r'This epoch took\s+([0-9]+(?:\.[0-9]+)?)\s*s', block)
        if times:
            epoch = int(match.group(1))
            require(len(times) == 1 and epoch not in completed and float(times[0]) > 0, 'Ambiguous epoch timing')
            completed[epoch] = float(times[0])
    require(set(completed) == set(range(300)), 'Need completed epochs0..299, not just epoch299 start')
    return completed


def check_architecture(record):
    require(record['variant'] == 'SFFN-Net_w_o_post_fusion_FFN' and record['targets'] == TARGETS
            and record['replacement'] == 'torch.nn.Identity', 'Not the four post-fusion FFN ablation')
    require(record['reference_fca_class'] == 'FCA' and record['reference_fca_flags'] == [True, True]
            and record['original_ffn_class'] == 'MixAttention', 'FCA class/flags differ')
    require(record['mfca_dasi_msplck_ss2d_psa_preserved'] is True
            and record['preserved_other_module_registrations_and_modes'] is True, 'Other components not preserved')
    require(record['removed_ffn_parameters'] == 1761884 and record['removed_registered_tensors'] == 92,
            'Removed FFN tensor/parameter counts differ')


def check_meta(meta):
    require(meta['name'] == 'unetr_pp_trainer_tumor_wo_ffn', 'Saved trainer is not w/o FFN')
    args = tuple(meta['init'])
    require(len(args) == 9 and Path(args[0]).resolve() == (TASK / 'unetr_pp_Plansv2.1_plans_3D.pkl').resolve(), 'Saved plan differs')
    require(args[1] == 0 and Path(args[2]).resolve() == FOLD.parent.resolve()
            and Path(args[3]).resolve() == TASK.resolve(), 'Saved fold/output/dataset differs')
    require(args[4] is False and args[5] == 0 and args[6] is True and args[7] is False and args[8] is False,
            'Saved batch-Dice/stage/unpack/deterministic/FP32 tuple differs')
    return args


def ids(folder, suffix):
    files = list(Path(folder).glob('*' + suffix))
    require(all(p.is_file() and not p.is_symlink() and p.stat().st_size > 0 for p in files), 'Empty/linked data file')
    return {p.name[:-len(suffix)] for p in files}


def original_geometry(properties):
    spacing = tuple(float(x) for x in properties['itk_spacing'])
    size = tuple(properties['original_size_of_raw_data'])
    require(len(spacing) == len(size) == 3 and all(math.isfinite(x) and x > 0 for x in spacing), 'Invalid original geometry')
    require(all(float(x).is_integer() and x > 0 for x in size), 'Invalid original size')
    require(all(abs(float(a) - b) <= 1e-5 for a, b in zip(properties['original_spacing'], spacing[::-1]))
            and len(properties['original_spacing']) == 3, 'Source XYZ/ZYX spacing differs')
    return dict(Size=[int(x) for x in size[::-1]], Spacing=spacing,
                Origin=tuple(properties['itk_origin']), Direction=tuple(properties['itk_direction']))


def check_geometry(actual, expected, label):
    for field in ('Size', 'Spacing', 'Origin', 'Direction'):
        a, b = actual[field], expected[field]
        require(len(a) == len(b) and all(math.isfinite(float(x)) and math.isfinite(float(y))
                and abs(float(x) - float(y)) <= 1e-5 for x, y in zip(a, b)), label + ' ' + field + ' differs')


def no_existing_export():
    require(not VERIFIED.exists() and not VERIFIED.is_symlink(), 'NPZ verification already exists; do not rerun')
    require(not TARGET.exists() and not TARGET.is_symlink(), 'Prediction path already exists; no overwrite/resume')


def audit():
    import SimpleITK as sitk
    require('a335-0b76b318' in socket.gethostname(), 'Not the FFN/Tumor instance')
    no_existing_export()
    training = json.loads((TRAIN_RUN / 'input_audit.json').read_text())
    require(training['seed'] == 42 and Path(training['output']).resolve() == OUTPUT.resolve(), 'Training audit identity differs')
    unchanged(training['source_sha256'])
    require((TRAIN_RUN / 'training.exit').read_text().strip() == '0', 'Training did not exit0')
    gpu = json.loads((TRAIN_RUN / 'gpu_preflight.json').read_text())
    require(gpu['status'] == 'REAL_NETWORK_FFN_PREFLIGHT_PASSED' and gpu['seed'] == 42,
            'Original real-network training preflight did not pass')
    require(sha(HERE / 'ffn_identity.py') == HELPER_SHA, 'NPZ helper differs from reviewed helper')
    original_helpers = {digest for path, digest in training['source_sha256'].items() if Path(path).name == 'ffn_identity.py'}
    require(original_helpers == {HELPER_SHA}, 'NPZ helper differs from helper used for training')
    parent = ROOT / 'unetr_pp/training/network_training/unetr_pp_trainer_tumor.py'
    require(sha(parent) == PARENT_SHA, 'Original Tumor parent trainer source differs')
    protected = dict(training['source_sha256'])

    def track(path):
        path = Path(path).resolve()
        digest = sha(path)
        require(str(path) not in protected or protected[str(path)] == digest, 'Pinned hash differs: ' + str(path))
        protected[str(path)] = digest

    for path in (HERE / 'ffn_identity.py', HERE / 'config.yaml', Path(__file__).resolve(),
                 TRAIN_RUN / 'input_audit.json', TRAIN_RUN / 'training.exit', TRAIN_RUN / 'gpu_preflight.json'):
        track(path)
    for path in (ROOT / 'config.yaml', HERE / 'config.yaml'):
        require(flags(path) == dict(MSS_en='true', FCA_en='true', FCA2_en='true'), 'All full-model switches must stay True')
        track(path)
    architecture_path = FOLD / 'ablation_architecture_audit.json'
    record = json.loads(architecture_path.read_text())
    check_architecture(record)
    require(record['trainer'] == 'unetr_pp_trainer_tumor_wo_ffn' and record['seed'] == 42 and record['fold'] == 0
            and record['max_num_epochs'] == 300 and record['config'] == dict(MSS_en=True, FCA_en=True, FCA2_en=True),
            'Saved architecture identity/schedule differs')
    require(record['seed_initialization_audit']['effective_seed'] == 42
            and record['seed_initialization_audit']['reference_deterministic'] is False,
            'Saved effective seed/deterministic audit differs')
    track(architecture_path)
    for relative, expected in record['audited_source_sha256'].items():
        source = ROOT / 'unetr_pp/network_architecture' / relative
        require(sha(source) == expected, 'Architecture source changed: ' + str(source))
        track(source)
    logs = sorted(FOLD.glob('training_log_*.txt'))
    completed_epochs('\n'.join(p.read_text(errors='replace') for p in logs))
    for path in logs:
        track(path)
    for name in ('model_best.model', 'model_best.model.pkl', 'model_final_checkpoint.model'):
        path = FOLD / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_size > 0, 'Missing checkpoint: ' + name)
        track(path)
    check_meta(pickle.loads((FOLD / 'model_best.model.pkl').read_bytes()))
    split_path = TASK / 'splits_final.pkl'
    require(sha(split_path) == SPLIT_SHA, 'Frozen split SHA differs')
    track(split_path)
    train, val = validate_split(pickle.loads(split_path.read_bytes())[0])
    for key, cases in (('train', train), ('val', val)):
        path = ROOT / 'experiment_manifests/tumor_fold0' / (key + '_cases.txt')
        require(path.read_text(encoding='utf-8') == '\n'.join(cases) + '\n', 'Frozen text manifest differs')
        track(path)
    plan_path = TASK / 'unetr_pp_Plansv2.1_plans_3D.pkl'
    plans = pickle.loads(plan_path.read_bytes()); track(plan_path)
    stage_plan = plans['plans_per_stage'][0]
    require(list(stage_plan['patch_size']) == [128, 128, 128] and stage_plan['batch_size'] == 2
            and plans['num_modalities'] == 4 and plans['num_classes'] == 3, 'Tumor plans differ')
    stage = TASK / (plans['data_identifier'] + '_stage0')
    for suffix in ('.npz', '.pkl', '.npy'):
        require(ids(stage, suffix) == set(train) | set(val), 'Preprocessed484case IDs differ: ' + suffix)
    for case in val:
        for path in (TASK / 'gt_segmentations' / (case + '.nii.gz'), stage / (case + '.pkl'),
                     stage / (case + '.npz'), stage / (case + '.npy')):
            track(path)
        properties = pickle.loads((stage / (case + '.pkl')).read_bytes())
        expected = original_geometry(properties)
        reader = sitk.ImageFileReader()
        reader.SetFileName(str(TASK / 'gt_segmentations' / (case + '.nii.gz')))
        reader.ReadImageInformation()
        actual = {field: tuple(getattr(reader, 'Get' + field)()) for field in ('Size', 'Spacing', 'Origin', 'Direction')}
        check_geometry(actual, expected, 'GT/source geometry ' + case)
    # Preserve any pre-existing training outputs, but do not recursively hash checkpoints twice.
    for path in FOLD.rglob('*'):
        require(not path.is_symlink(), 'Linked training output')
        if path.is_file() and str(path.resolve()) not in protected:
            track(path)
    print('TUMOR_WO_FFN_SEED42_NPZ_PREFLIGHT_PASSED', flush=True)
    print('TRAINING_COMPLETED=300; train387 validation97 overlap0; fourFFN Identity only', flush=True)
    print('CHECKPOINT=' + str(FOLD / 'model_best.model'), flush=True)
    print('SAVE_TO=' + str(TARGET), flush=True)
    return dict(status='TUMOR_WO_FFN_SEED42_NPZ_PREFLIGHT_PASSED', seed=42, fold=0,
                train_ids=train, validation_ids=val, checkpoint=str(FOLD / 'model_best.model'),
                architecture_record=record, protected_sha256=protected, target=str(TARGET),
                training_run=str(TRAIN_RUN), prediction_precision='FP32', checkpoint_loading='strict state_dict; no optimizer restore')


def idle_gpu():
    text = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader'], text=True)
    require(not text.strip(), 'GPU is busy: ' + text.strip())


def environment(gpu, run_dir):
    env = os.environ.copy()
    env.update(CUDA_VISIBLE_DEVICES='0' if gpu else '', PYTHONHASHSEED='42', EXPERIMENT_SEED='42',
               PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1', SFFN_PROJECT_ROOT=str(ROOT),
               RESULTS_FOLDER=str(run_dir / 'runtime_results'),
               unetr_pp_preprocessed=str(TASK.parent),
               unetr_pp_raw_data_base=str(ROOT / 'DATASET_Tumor/unetr_pp_raw'),
               PYTHONPATH=os.pathsep.join([str(HERE), str(ROOT), env.get('PYTHONPATH', '')]))
    env.pop('FFN_DISPOSABLE_PREFLIGHT', None)
    return env


def canonical_state(saved, expected):
    require(isinstance(saved, dict) and bool(saved), 'Checkpoint state_dict missing')
    keys = set(saved)
    if keys == set(expected):
        return saved
    require(all(k.startswith('module.') for k in saved), 'State keys differ; no permissive loading')
    stripped = OrderedDict((k[7:], value) for k, value in saved.items())
    require(set(stripped) == set(expected), 'State keys differ after uniform DataParallel prefix removal')
    return stripped


def check_state_tensors(net, saved, torch):
    actual = net.state_dict()
    require(set(actual) == set(saved), 'Model state key set changed')
    for key, value in saved.items():
        require(tuple(actual[key].shape) == tuple(value.shape) and actual[key].dtype == value.dtype,
                'State shape/dtype differs: ' + key)
        require(torch.equal(actual[key].detach().cpu(), value.detach().cpu()), 'State tensor differs from best checkpoint: ' + key)


def reconstruct_and_validate(manifest, run_dir):
    import numpy as np
    import torch
    from ffn_identity import apply_ffn_identity
    from unetr_pp.network_architecture.tumor import model_components as model
    from unetr_pp.training.network_training.unetr_pp_trainer_tumor import unetr_pp_trainer_tumor as Parent
    require(all(v is True for v in (model.MSS_en, model.FCA_en, model.FCA2_en)), 'Actually imported switches differ')
    require(Path(inspect.getsourcefile(Parent)).resolve() == (ROOT / 'unetr_pp/training/network_training/unetr_pp_trainer_tumor.py').resolve(),
            'Imported parent comes from another checkout')
    require(torch.cuda.is_available(), 'CUDA unavailable')
    class InferenceOnlyFFN(Parent):
        def initialize_optimizer_and_scheduler(self):
            require(self.optimizer is None and not hasattr(self, 'inference_architecture_report'), 'Optimizer/ablation already initialized')
            self.inference_architecture_report = apply_ffn_identity(self.network, optimizer=None,
                         expected_fca_class='FCA', project_root=str(ROOT))
            check_architecture(self.inference_architecture_report)
            self.lr_scheduler = None

        def do_split(self):
            require(self.fold == 0 and set(self.dataset) == set(manifest['train_ids']) | set(manifest['validation_ids']),
                    'Runtime dataset differs from frozen split')
            self.dataset_tr = OrderedDict((case, self.dataset[case]) for case in manifest['train_ids'])
            self.dataset_val = OrderedDict((case, self.dataset[case]) for case in manifest['validation_ids'])
            print('RUNTIME_SPLIT_VERIFIED: train387 val97 overlap0', flush=True)

        def run_training(self, *args, **kwargs):
            raise RuntimeError('Training is forbidden in this NPZ-only entry')

        def run_iteration(self, *args, **kwargs):
            raise RuntimeError('Training iterations are forbidden in this NPZ-only entry')

        def save_checkpoint(self, *args, **kwargs):
            raise RuntimeError('Checkpoint saving is forbidden in this NPZ-only entry')

    meta = pickle.loads((FOLD / 'model_best.model.pkl').read_bytes())
    args = list(check_meta(meta))
    args[2] = str(run_dir / 'validation_runtime')
    tr = InferenceOnlyFFN(*args)
    require(tr.was_initialized is False and tr.network is None and tr.optimizer is None, 'Unexpected eager initialization')
    random.seed(42); np.random.seed(42); torch.manual_seed(42); torch.cuda.manual_seed_all(42)
    tr.initialize(training=False)
    require(tr.was_initialized is True and tr.optimizer is None and tr.tr_gen is None and tr.val_gen is None,
            'Training optimizer/generators must never exist')
    require(Path(tr.output_folder).resolve().is_relative_to(run_dir.resolve()), 'Trainer output escaped scratch run')
    require(Path(tr.output_folder_base).resolve().is_relative_to(run_dir.resolve()), 'Trainer base output escaped scratch run')
    require(tr.fp16 is False and tr.deterministic is False and int(tr.batch_size) == 2
            and list(map(int, tr.patch_size)) == [128, 128, 128], 'Runtime protocol differs')
    for field in ('removed_ffn_parameters', 'removed_registered_tensors', 'preserved_registered_tensors', 'audited_source_sha256'):
        require(tr.inference_architecture_report[field] == manifest['architecture_record'][field], 'Rebuilt architecture receipt differs: ' + field)
    kwargs = {'map_location': 'cpu'}
    if 'weights_only' in inspect.signature(torch.load).parameters:
        kwargs['weights_only'] = False
    checkpoint = torch.load(manifest['checkpoint'], **kwargs)
    require(isinstance(checkpoint, dict) and 'state_dict' in checkpoint, 'Checkpoint container differs')
    saved = canonical_state(checkpoint['state_dict'], tr.network.state_dict())
    checkpoint_epoch = checkpoint.get('epoch')
    require(not any(any(k.startswith(target + '.') for target in TARGETS) for k in saved), 'Removed FFN tensors remain in checkpoint')
    for key, value in saved.items():
        require(tuple(value.shape) == tuple(tr.network.state_dict()[key].shape)
                and value.dtype == tr.network.state_dict()[key].dtype, 'Checkpoint tensor shape/dtype differs: ' + key)
        require(bool(torch.isfinite(value).all()), 'Nonfinite checkpoint tensor: ' + key)
    tr.network.load_state_dict(saved, strict=True)
    check_state_tensors(tr.network, saved, torch)
    tr.network.eval()
    print('WO_FFN_STRICT_BEST_CHECKPOINT_LOADED; no optimizer constructed/restored', flush=True)
    enc = tr.network.unetr_pp_encoder
    components = dict(MSPLCK=enc.MSS.lsblock, SS2D=enc.MSS.op, PSA=enc.MSS.mlp)
    for i in range(4):
        fca = getattr(enc, f'FCA{i}')
        require(type(fca.FFN) is torch.nn.Identity, 'A post-fusion FFN was not removed')
        components.update({f'MFCA{i}': fca.Fre, f'DASI{i}': fca.DASI, f'IdentityFFN{i}': fca.FFN})
    calls = {name: 0 for name in components}
    def counter(name):
        def hook(module, inputs, output): calls[name] += 1
        return hook
    handles = [module.register_forward_hook(counter(name)) for name, module in components.items()]
    options = dict(do_mirroring=True, use_sliding_window=True, step_size=.5, save_softmax=True,
                   use_gaussian=True, overwrite=False, validation_folder_name='validation_best_npz', all_in_gpu=False)
    signature = inspect.signature(tr.validate)
    require(all(k in signature.parameters for k in options) or
            any(p.kind == inspect.Parameter.VAR_KEYWORD for p in signature.parameters.values()), 'Validate signature differs')
    require(tuple(tr.data_aug_params['mirror_axes']) == (0, 1, 2), 'Mirroring axes differ')
    try:
        with torch.no_grad():
            tr.validate(**options)
    finally:
        for handle in handles: handle.remove()
    torch.cuda.synchronize()
    require(all(count > 0 for count in calls.values()), 'An identity/retained component never ran: ' + repr(calls))
    require(tr.optimizer is None and tr.tr_gen is None and tr.val_gen is None, 'Training state appeared during validation')
    check_state_tensors(tr.network, saved, torch)
    new_json(run_dir / 'runtime_architecture_and_checkpoint.json',
             dict(status='WO_FFN_BEST_CHECKPOINT_AND_REAL_VALIDATION_FORWARD_VERIFIED',
                  checkpoint=manifest['checkpoint'], checkpoint_epoch=int(checkpoint_epoch) if checkpoint_epoch is not None else None,
                  strict_state_dict=True, optimizer_created=False,
                  architecture=tr.inference_architecture_report, component_calls=calls,
                  model_state_unchanged_after_validation=True, inference_options=options,
                  gpu=torch.cuda.get_device_name(0), torch_version=torch.__version__))
    return Path(tr.output_folder) / 'validation_best_npz'


def verify_export(folder, manifest):
    import numpy as np
    import SimpleITK as sitk
    val = set(manifest['validation_ids'])
    for suffix in ('.nii.gz', '.npz', '.pkl'):
        require(ids(folder, suffix) == val, 'Export97case IDs differ: ' + suffix)
    hashes, max_error = {}, 0.0
    for index, case in enumerate(sorted(val), 1):
        mask = sitk.ReadImage(str(folder / (case + '.nii.gz')))
        gt = sitk.ReadImage(str(TASK / 'gt_segmentations' / (case + '.nii.gz')))
        require(mask.GetSize() == gt.GetSize(), 'Mask/GT size differs: ' + case)
        for field in ('Spacing', 'Origin', 'Direction'):
            a, b = getattr(mask, 'Get' + field)(), getattr(gt, 'Get' + field)()
            require(np.allclose(a, b, rtol=0, atol=1e-5), 'Mask/GT ' + field + ' differs: ' + case)
        require(set(np.unique(sitk.GetArrayFromImage(mask)).tolist()) <= {0, 1, 2, 3}, 'Unexpected predicted labels')
        with np.load(folder / (case + '.npz'), allow_pickle=False) as saved:
            a = saved['softmax']
            require(a.ndim == 4 and a.shape[0] == 4 and np.isfinite(a).all(), 'Invalid four-class softmax')
            error = float(np.max(np.abs(a.sum(axis=0, dtype=np.float32) - 1)))
            require(a.min() >= -.001 and a.max() <= 1.001 and error <= .01, 'Softmax range/sum differs')
            max_error = max(max_error, error)
        for suffix in ('.nii.gz', '.npz', '.pkl'):
            p = folder / (case + suffix)
            hashes[p.name] = sha(p)
        if index % 25 == 0:
            print(f'WO_FFN_EXPORT_AUDIT={index}/97', flush=True)
    require(all(not p.is_symlink() for p in folder.rglob('*')), 'Linked generated output')
    return dict(masks=97, softmax=97, properties=97, geometry_checked=97,
                max_softmax_sum_abs_error=max_error, generated_file_sha256=hashes)


def publish(folder, run_dir):
    require(folder.resolve().is_relative_to(run_dir.resolve()) and folder.name == 'validation_best_npz'
            and not folder.is_symlink(), 'Invalid generated source folder')
    require(TARGET.parent.resolve() == FOLD.resolve() and FOLD.resolve().is_relative_to(OUTPUT.resolve()), 'Invalid publication target')
    no_existing_export()
    original_inode = folder.stat()
    require(original_inode.st_dev == FOLD.stat().st_dev, 'Scratch and final folders must share a filesystem')
    # No-clobber move of our NEW, fully verified export only; never move old data.
    subprocess.run(['mv', '-T', '-n', '--', str(folder), str(TARGET)], check=True)
    require(not folder.exists() and TARGET.is_dir() and not TARGET.is_symlink(), 'Publication did not complete; inspect scratch output')
    now = TARGET.stat()
    require((now.st_dev, now.st_ino) == (original_inode.st_dev, original_inode.st_ino), 'Publication inode differs')


@contextmanager
def lock(wait=False):
    import fcntl
    with (ROOT / 'run_logs/tumor_wo_ffn_seed42_npz.runtime.lock').open('a') as stream:
        fcntl.flock(stream, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        yield


def worker(run_dir):
    require('a335-0b76b318' in socket.gethostname(), 'Not the FFN instance')
    require(run_dir.parent.resolve() == (ROOT / 'run_logs').resolve()
            and run_dir.name.startswith('tumor_wo_ffn_seed42_npz_') and not run_dir.is_symlink(), 'Invalid run directory')
    with lock(wait=True):
        manifest = json.loads((run_dir / 'preflight.json').read_text())
        unchanged(manifest['protected_sha256']); no_existing_export(); idle_gpu()
        os.environ.update(environment(True, run_dir))
        os.chdir(HERE)
        sys.path[:0] = [str(HERE), str(ROOT)]
        folder = reconstruct_and_validate(manifest, run_dir)
        export = verify_export(folder, manifest)
        unchanged(manifest['protected_sha256'])
        publish(folder, run_dir)
        for name, digest in export['generated_file_sha256'].items():
            require(sha(TARGET / name) == digest, 'Published export changed: ' + name)
        unchanged(manifest['protected_sha256'])
        new_json(VERIFIED, dict(status=STATUS, seed=42, fold=0, prediction_directory=str(TARGET),
                 preflight_manifest=str(run_dir / 'preflight.json'), training_architecture_report_unchanged=True,
                 checkpoint_and_sources_unchanged=True, formal_cpu_metrics_not_started=True,
                 validation_ids=manifest['validation_ids'], **export))
        print(STATUS + ': masks=97 softmax=97 pkl=97; frozen IDs match', flush=True)
        print('CHECKPOINT_SOURCES_AND_ORIGINAL_ARCHITECTURE_REPORT_UNCHANGED', flush=True)
        print('SAVED_TO=' + str(TARGET), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--run', action='store_true')
    group.add_argument('--worker', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        code = 1
        try:
            worker(args.worker); code = 0
        except Exception:
            traceback.print_exc()
        finally:
            if (args.worker.parent.resolve() == (ROOT / 'run_logs').resolve() and args.worker.is_dir()
                    and args.worker.name.startswith('tumor_wo_ffn_seed42_npz_') and not args.worker.is_symlink()):
                with (args.worker / 'npz.exit').open('x') as stream:
                    stream.write(str(code) + '\n')
        raise SystemExit(code)
    manifest = audit()
    if not args.run:
        print('AUDIT_ONLY; no inference started. Add --run.'); return
    with lock():
        idle_gpu()
        screen = subprocess.run(['screen', '-ls'], capture_output=True, text=True)
        require('.' + SESSION not in screen.stdout, 'FFN seed42 NPZ screen already exists')
        run_dir = ROOT / 'run_logs' / ('tumor_wo_ffn_seed42_npz_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_UTC_') + uuid4().hex[:8])
        run_dir.mkdir(exist_ok=False)
        new_json(run_dir / 'preflight.json', manifest)
        command = 'set -o noclobber; exec "$1" -u "$2" --worker "$3" > "$3/screen.log" 2>&1'
        subprocess.run(['screen', '-dmS', SESSION, 'bash', '-c', command, 'ffn-npz', sys.executable,
                        str(Path(__file__).resolve()), str(run_dir)], env=environment(False, run_dir), check=True)
    print('SCREEN_DISPATCHED=' + SESSION)
    print('LOG=' + str(run_dir / 'screen.log'))
    print('EXIT_FILE=' + str(run_dir / 'npz.exit'))
    print('SAVE_TO=' + str(TARGET))
    print('Require ' + STATUS + ' and EXIT_CODE=0; dispatch is not completion.')


if __name__ == '__main__':
    main()
