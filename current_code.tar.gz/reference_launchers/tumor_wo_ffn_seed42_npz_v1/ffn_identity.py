"""Architecture-only Tumor w/o post-fusion FFN; never launches training.

Replace FCA0..FCA3.FFN, not MSS.mlp (PSA) or Transformer feed-forward layers.
Construct and initialize the verified complete SFFN-Net first, then call the
transform before optimizer creation. No other ablation may already be applied.
This standalone tool does not import or apply any other ablation tool.
"""

from __future__ import annotations

import hashlib
import inspect
from pathlib import Path


_SOURCE_SHA256 = {
    "tumor/unetr_pp_tumor.py": "96fdbdc9c15b9924cdc0aad1011594a209c48181076da5183432f0536ad99b9c",
    "tumor/model_components.py": "b23e50bfaddace75b2f8fe1ea7fe54b27f364b940ae51161a930a5760c03786c",
    "tumor/transformerblock.py": "55c3a665970405b7efe5f59a65805b5f8b7bb7ad834f00190dbe786dc430f3ae",
    "mamba.py": "903c8f90ee852474806a86bdd5db34af176ee4d38bdbcce61bc66dae01af7a2c",
    "common.py": "a59f51f12b9a6ffde99ed29b9376f3e2e715a8bf0e4ca1d49cd4ff18eb0e43aa",
}


class AblationAuditError(RuntimeError):
    """The supplied network/input differs from the audited contract."""


def _require(condition, message):
    if not condition:
        raise AblationAuditError(message)


def _tensor_registry(network):
    """Record tensor identities/metadata, not tensor content hashes."""
    result = {}
    for kind, values in (
        ("parameter", network.named_parameters(remove_duplicate=False)),
        ("buffer", network.named_buffers(remove_duplicate=False)),
    ):
        for name, value in values:
            result[(kind, name)] = (
                id(value), tuple(value.shape), str(value.dtype),
                str(value.device), value.requires_grad, value._version,
            )
    return result


def _verify_source(module, project_root, relative_path):
    expected = (Path(project_root) / "unetr_pp/network_architecture" /
                relative_path).resolve(strict=True)
    actual = inspect.getsourcefile(type(module))
    _require(actual is not None, f"Cannot identify source for {type(module).__name__}")
    _require(Path(actual).resolve(strict=True) == expected,
             f"Imported class is not from the audited project: {actual}")
    digest = hashlib.sha256(expected.read_bytes()).hexdigest()
    _require(digest == _SOURCE_SHA256[relative_path],
             f"Source changed; re-audit before training: {expected} SHA256={digest}")
    return digest


def apply_ffn_identity(network, *, optimizer, expected_fca_class, project_root):
    """Replace exactly four ``unetr_pp_encoder.FCA{0..3}.FFN`` modules.

    The audited FCA.forward still runs MFCA, DASI, its 5D->4D reshape,
    Identity, and its 4D->5D reshape. No extra residual is inserted: the DASI
    output is propagated directly. FCA.FFN is MixAttention; FCA2.FFN is
    MixAttention2. Keep the verified reference choice and all module switches.

    MSS.op/lsblock/mlp and Transformer layers are untouched, even if a comment
    calls MSS.mlp an FFN. MSS.mlp is the separate PSA component in this source.

    optimizer=None is a caller contract, not proof of trainer lifecycle. Source
    and registration checks do not prove a real forward/backward pass, correct
    split/seed/schedule or checkpoint provenance. Train from scratch only.
    """
    _require(optimizer is None, "Apply the ablation before optimizer creation.")
    _require(expected_fca_class in {"FCA", "FCA2"},
             "Verify and explicitly provide the reference FCA/FCA2 class first.")

    from torch import nn

    _require(isinstance(network, nn.Module), "Expected an initialized torch model.")
    encoder = getattr(network, "unetr_pp_encoder", None)
    _require(isinstance(encoder, nn.Module), "Missing Tumor encoder.")
    source_hashes = {
        "tumor/unetr_pp_tumor.py": _verify_source(
            network, project_root, "tumor/unetr_pp_tumor.py"),
        "tumor/model_components.py": _verify_source(
            encoder, project_root, "tumor/model_components.py"),
    }
    _require(hasattr(encoder, "stages") and len(encoder.stages) == 4 and
             len(encoder.stages[0]) > 0, "Expected four complete encoder stages.")
    source_hashes["tumor/transformerblock.py"] = _verify_source(
        encoder.stages[0][0], project_root, "tumor/transformerblock.py")
    _require(getattr(encoder, "MSS_en", None) is True,
             "The complete MSS path must remain enabled.")
    flags = (getattr(encoder, "FCA_en", None), getattr(encoder, "FCA2_en", None))
    _require(flags == {"FCA": (True, True), "FCA2": (False, True)}[expected_fca_class],
             f"Reference FCA flags do not match {expected_fca_class}: {flags}")
    mss = getattr(encoder, "MSS", None)
    _require(type(mss).__name__ == "MSSBlock", "Missing complete MSSBlock.")
    source_hashes["mamba.py"] = _verify_source(mss, project_root, "mamba.py")
    _require(getattr(mss, "ssm_branch", None) is True and
             getattr(mss, "mlp_branch", None) is True,
             "SS2D and PSA must both remain enabled.")
    for attribute, expected_type, source in (
        ("op", "SS2D", "mamba.py"), ("lsblock", "Mix", "common.py"),
        ("mlp", "PSA_s", "common.py"),
    ):
        component = getattr(mss, attribute, None)
        _require(type(component).__name__ == expected_type,
                 f"Preserved component {attribute} is not {expected_type}.")
        source_hashes[source] = _verify_source(component, project_root, source)
    for attribute in ("proj_conv", "norm", "norm2", "drop_path"):
        _require(hasattr(mss, attribute), f"Missing preserved MSS wrapper: {attribute}")

    targets = {}
    expected_ffn = {"FCA": "MixAttention", "FCA2": "MixAttention2"}[expected_fca_class]
    for stage in range(4):
        name = f"FCA{stage}"
        fca = getattr(encoder, name, None)
        _require(type(fca).__name__ == expected_fca_class,
                 f"{name} differs from the verified reference class.")
        source_hashes["common.py"] = _verify_source(fca, project_root, "common.py")
        for attribute, expected_type in (
            ("Fre", "MultiFrequencyChannelAttention"), ("DASI", "DASI"),
            ("FFN", expected_ffn),
        ):
            component = getattr(fca, attribute, None)
            _require(type(component).__name__ == expected_type,
                     f"{name}.{attribute} is not the complete-model {expected_type}.")
            _verify_source(component, project_root, "common.py")
        original = fca.FFN
        for hook_name in (
            "_forward_hooks", "_forward_pre_hooks", "_backward_hooks",
            "_backward_pre_hooks", "_state_dict_hooks", "_state_dict_pre_hooks",
            "_load_state_dict_pre_hooks", "_load_state_dict_post_hooks",
        ):
            _require(not getattr(original, hook_name, {}),
                     f"Target FFN container hooks cannot be silently discarded: {hook_name}")
        _require(any(True for _ in original.parameters()),
                 f"{name}.FFN has no original parameters; re-audit required.")
        targets[f"unetr_pp_encoder.{name}.FFN"] = (fca, original)

    def within_target(name):
        return any(name == target or name.startswith(target + ".") for target in targets)

    modules_before = list(network.named_modules(remove_duplicate=False))
    for target, (_, original) in targets.items():
        occurrences = [name for name, module in modules_before if module is original]
        _require(occurrences == [target], f"An FFN target is aliased or misplaced: {occurrences}")
    # Deliberately do not search-and-replace every MixAttention or FeedForward
    # in the network. Unrelated uses must remain unchanged.
    before = _tensor_registry(network)
    state_before = set(network.state_dict())
    removed = {key for key in before if within_target(key[1])}
    protected = {key: value for key, value in before.items() if key not in removed}
    _require(not ({value[0] for key, value in before.items() if key in removed} &
                  {value[0] for value in protected.values()}),
             "FFN shares a tensor with a preserved component; re-audit required.")
    removed_parameter_ids = {value[0] for key, value in before.items()
                             if key in removed and key[0] == "parameter"}
    removed_parameter_count = sum(p.numel() for p in network.parameters()
                                  if id(p) in removed_parameter_ids)
    preserved_modules = {name: (id(module), module.training)
                         for name, module in modules_before if not within_target(name)}

    try:
        for fca, original in targets.values():
            fca.FFN = nn.Identity().train(original.training)
        _require(all(type(fca.FFN) is nn.Identity for fca, _ in targets.values()),
                 "Not all four post-fusion FFNs were replaced with Identity.")
        _require(_tensor_registry(network) == protected,
                 "A non-FFN tensor changed or a target tensor remains.")
        _require(set(network.state_dict()) == {name for name in state_before
                                               if not within_target(name)},
                 "Unexpected state_dict changes outside the target FFNs.")
        after_modules = dict(network.named_modules(remove_duplicate=False))
        _require(all(name in after_modules and
                     (id(after_modules[name]), after_modules[name].training) == identity_and_mode
                     for name, identity_and_mode in preserved_modules.items()),
                 "A preserved module or its train/eval mode changed.")
    except Exception:
        for fca, original in targets.values():
            fca.FFN = original
        raise

    return {
        "variant": "SFFN-Net_w_o_post_fusion_FFN",
        "targets": list(targets),
        "replacement": "torch.nn.Identity",
        "propagation": "DASI_output_directly_through_original_reshapes",
        "reference_fca_class": expected_fca_class,
        "original_ffn_class": expected_ffn,
        "reference_fca_flags": list(flags),
        "audited_source_sha256": source_hashes,
        "removed_ffn_parameters": removed_parameter_count,
        "removed_registered_tensors": len(removed),
        "preserved_registered_tensors": len(protected),
        "preserved_other_module_registrations_and_modes": True,
        "mfca_dasi_msplck_ss2d_psa_preserved": True,
        "forward_and_training_preflight_complete": False,
    }


def check_model_forward_backward(
    network, example_input, *, optimizer, disposable_model,
    expected_output_shapes, required_gradient_names, loss_builder=None,
):
    """Explicit, optional diagnostic; never called on import or transformation.

    On the server supply the actual ablated Tumor network, plan-sized floating
    input and independently expected output shapes. No device is automatically
    chosen and no optimizer step is executed. A toy fixture certifies only
    itself, not the actual SFFN-Net. Select active preserved gradient names;
    removed FFN parameters and dormant branches cannot be required gradients.

    This modifies training modes, gradients, BN buffers and RNG state. Use a
    disposable model and reconstruct the real training model from its original
    seed afterwards. The default loss is a synthetic connectivity probe, not
    validation of the actual segmentation loss. Pass loss_builder explicitly
    to check a real criterion with targets captured by the caller.
    """
    _require(optimizer is None, "No optimizer is permitted in the diagnostic.")
    _require(disposable_model is True,
             "Use a disposable diagnostic model, then rebuild before training.")
    import torch
    from torch import nn

    _require(isinstance(network, nn.Module), "Expected a torch model.")
    _require(isinstance(example_input, torch.Tensor) and example_input.is_floating_point(),
             "Provide a floating-point input tensor explicitly.")
    _require(torch.isfinite(example_input).all().item(), "Input contains NaN or Inf.")
    parameters = dict(network.named_parameters())
    _require(parameters and not any(p.grad is not None for p in parameters.values()),
             "Use a fresh diagnostic model with no existing parameter gradients.")
    _require(all(value.device == example_input.device
                 for value in list(parameters.values()) + list(network.buffers())),
             "Model tensors and the explicit input must be on the same device.")
    required_names = tuple(required_gradient_names)
    _require(required_names and len(set(required_names)) == len(required_names),
             "Explicitly list distinct active preserved parameters to check.")
    _require(all(name in parameters and parameters[name].requires_grad for name in required_names),
             "A required gradient name is missing or frozen.")
    expected_shapes = [tuple(shape) for shape in expected_output_shapes]
    _require(expected_shapes, "Expected output shapes must be supplied independently.")
    network.train()
    probe = example_input.detach().clone().requires_grad_(True)
    raw_outputs = network(probe)
    outputs = [raw_outputs] if isinstance(raw_outputs, torch.Tensor) else raw_outputs
    _require(isinstance(outputs, (tuple, list)) and outputs and
             all(isinstance(output, torch.Tensor) for output in outputs),
             "Expected one Tensor or a nonempty deep-supervision Tensor sequence.")
    actual_shapes = [tuple(output.shape) for output in outputs]
    _require(actual_shapes == expected_shapes,
             f"Output shapes differ: expected={expected_shapes}, actual={actual_shapes}")
    _require(all(output.is_floating_point() and torch.isfinite(output).all().item()
                 for output in outputs), "An output contains NaN/Inf or is not floating point.")
    loss = (sum(output.float().square().mean() for output in outputs) / len(outputs)
            if loss_builder is None else loss_builder(raw_outputs))
    _require(isinstance(loss, torch.Tensor) and loss.numel() == 1 and loss.requires_grad and
             torch.isfinite(loss).all().item(),
             "Diagnostic loss must be a finite differentiable scalar Tensor.")
    loss.backward()
    _require(probe.grad is not None and torch.isfinite(probe.grad).all().item(),
             "The input did not receive a finite gradient.")
    gradients = {name: parameter.grad for name, parameter in parameters.items()
                 if parameter.grad is not None}
    _require(all(torch.isfinite(gradient).all().item() for gradient in gradients.values()),
             "A produced parameter gradient contains NaN or Inf.")
    _require(all(name in gradients and gradients[name].abs().sum().item() > 0
                 for name in required_names),
             "A required active preserved parameter has no nonzero gradient.")
    return {
        "supplied_model_class": type(network).__name__,
        "device": str(example_input.device),
        "output_shapes": actual_shapes,
        "finite_outputs_loss_and_gradients": True,
        "required_nonzero_gradient_names": list(required_names),
        "parameters_receiving_gradients": len(gradients),
        "loss_kind": "synthetic_connectivity_probe" if loss_builder is None else "caller_supplied",
        "loss_value": loss.detach().item(),
        "forward_backward_checks_passed_for_supplied_model": True,
        "optimizer_steps": 0,
        "rebuild_from_original_seed_before_training": True,
        "training_protocol_preflight_complete": False,
    }
