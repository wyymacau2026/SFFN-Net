"""Standard-library/NumPy guards. Actual PyTorch/NIfTI/GPU checks run on server."""
import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

SOURCE = Path(__file__).with_name('run_tumor_wo_ffn_seed42_npz.py')
spec = importlib.util.spec_from_file_location('ffn_npz', SOURCE)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def receipt():
    return dict(variant='SFFN-Net_w_o_post_fusion_FFN', targets=list(m.TARGETS),
                replacement='torch.nn.Identity', reference_fca_class='FCA', reference_fca_flags=[True, True],
                original_ffn_class='MixAttention', mfca_dasi_msplck_ss2d_psa_preserved=True,
                preserved_other_module_registrations_and_modes=True, removed_ffn_parameters=1761884,
                removed_registered_tensors=92)


def metadata():
    return dict(name='unetr_pp_trainer_tumor_wo_ffn', init=(str(m.TASK / 'unetr_pp_Plansv2.1_plans_3D.pkl'),
                0, str(m.FOLD.parent), str(m.TASK), False, 0, True, False, False))


class GuardTests(unittest.TestCase):
    def test_complete_300_epochs(self):
        text = '\n'.join(f'epoch: {i}\nThis epoch took 150.5 s' for i in range(300))
        self.assertEqual(len(m.completed_epochs(text)), 300)

    def test_last_epoch_start_is_not_completion(self):
        text = '\n'.join(f'epoch: {i}\nThis epoch took 150.5 s' for i in range(299)) + '\nepoch: 299'
        with self.assertRaises(RuntimeError): m.completed_epochs(text)

    def test_acdc_budget_not_accepted(self):
        text = '\n'.join(f'epoch: {i}\nThis epoch took 150.5 s' for i in range(1000))
        with self.assertRaises(RuntimeError): m.completed_epochs(text)

    def test_duplicate_epoch_timing_rejected(self):
        with self.assertRaises(RuntimeError): m.completed_epochs('epoch: 0\nThis epoch took 1 s\nThis epoch took 2 s')

    def test_frozen_split(self):
        s = dict(train=[f't{i}' for i in range(387)], val=[f'v{i}' for i in range(97)])
        self.assertEqual(tuple(map(len, m.validate_split(s))), (387, 97))
        s['val'][0] = s['train'][0]
        with self.assertRaises(RuntimeError): m.validate_split(s)

    def test_duplicate_val_rejected(self):
        s = dict(train=[f't{i}' for i in range(387)], val=['v0'] * 97)
        with self.assertRaises(RuntimeError): m.validate_split(s)

    def test_exact_four_ffn_receipt(self):
        m.check_architecture(receipt())

    def test_psa_is_not_post_fusion_ffn(self):
        r = receipt(); r['targets'] = ['unetr_pp_encoder.MSS.mlp']
        with self.assertRaises(RuntimeError): m.check_architecture(r)

    def test_preserved_components_required(self):
        r = receipt(); r['mfca_dasi_msplck_ss2d_psa_preserved'] = False
        with self.assertRaises(RuntimeError): m.check_architecture(r)

    def test_removed_parameter_count_pinned(self):
        r = receipt(); r['removed_ffn_parameters'] += 1
        with self.assertRaises(RuntimeError): m.check_architecture(r)

    def test_saved_meta(self):
        self.assertEqual(len(m.check_meta(metadata())), 9)

    def test_baseline_checkpoint_meta_rejected(self):
        x = metadata(); x['name'] = 'unetr_pp_trainer_tumor'
        with self.assertRaises(RuntimeError): m.check_meta(x)

    def test_saved_deterministic_not_overridden(self):
        x = metadata(); args = list(x['init']); args[7] = True; x['init'] = args
        with self.assertRaises(RuntimeError): m.check_meta(x)

    def test_bare_checkpoint_keys(self):
        saved = {'a': object(), 'b': object()}
        self.assertIs(m.canonical_state(saved, saved), saved)

    def test_source_geometry_axis_order(self):
        p = dict(itk_spacing=(1, 2, 3), original_spacing=(3, 2, 1), original_size_of_raw_data=(9, 11, 13),
                 itk_origin=(0, 0, 0), itk_direction=(1, 0, 0, 0, 1, 0, 0, 0, 1))
        g = m.original_geometry(p)
        self.assertEqual(g['Size'], [13, 11, 9])
        self.assertEqual(g['Spacing'], (1, 2, 3))

    def test_geometry_mismatch_rejected_before_gpu(self):
        g = dict(Size=(3, 3, 3), Spacing=(1, 1, 1), Origin=(0, 0, 0), Direction=(1, 0, 0, 0, 1, 0, 0, 0, 1))
        m.check_geometry(g, g, 'test')
        with self.assertRaises(RuntimeError): m.check_geometry(g, dict(g, Spacing=(1, 1, 10)), 'test')

    def test_uniform_dataparallel_prefix(self):
        self.assertEqual(m.canonical_state({'module.a': 1, 'module.b': 2}, {'a': 0, 'b': 0}), {'a': 1, 'b': 2})

    def test_mixed_prefix_rejected(self):
        with self.assertRaises(RuntimeError): m.canonical_state({'a': 1, 'module.b': 2}, {'a': 0, 'b': 0})

    def test_missing_state_rejected(self):
        with self.assertRaises(RuntimeError): m.canonical_state({'module.a': 1}, {'a': 0, 'b': 0})

    def test_original_ffn_extra_keys_rejected(self):
        with self.assertRaises(RuntimeError):
            m.canonical_state({'module.a': 1, 'module.unetr_pp_encoder.FCA0.FFN.weight': 2}, {'a': 0})

    def test_no_existing_prediction_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            target, verified = Path(d) / 'prediction', Path(d) / 'verified.json'
            with mock.patch.multiple(m, TARGET=target, VERIFIED=verified):
                m.no_existing_export(); target.mkdir()
                with self.assertRaises(RuntimeError): m.no_existing_export()

    def test_existing_verified_marker_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            target, verified = Path(d) / 'prediction', Path(d) / 'verified.json'
            m.new_json(verified, {'ok': True})
            with mock.patch.multiple(m, TARGET=target, VERIFIED=verified):
                with self.assertRaises(RuntimeError): m.no_existing_export()

    def test_json_never_overwrites(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'audit.json'; m.new_json(p, {'original': True})
            with self.assertRaises(FileExistsError): m.new_json(p, {'original': False})
            self.assertTrue(json.loads(p.read_text())['original'])

    def test_duplicate_flags_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'config.yaml'
            with p.open('x') as f: f.write('MSS_en: true\nMSS_en: false\n')
            with self.assertRaises(RuntimeError): m.flags(p)

    def test_inference_override_never_constructs_optimizer(self):
        tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
        cls = next(n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == 'InferenceOnlyFFN')
        methods = {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
        for forbidden in ('run_training', 'run_iteration', 'save_checkpoint'):
            self.assertIsInstance(methods[forbidden].body[0], ast.Raise)
        hook = methods['initialize_optimizer_and_scheduler']
        self.assertFalse(any(isinstance(n, ast.Name) and n.id == 'super' for n in ast.walk(hook)))
        text = SOURCE.read_text(encoding='utf-8')
        self.assertNotIn('strict=False', text)
        self.assertIn('load_state_dict(saved, strict=True)', text)
        self.assertIn('tr.initialize(training=False)', text)
        self.assertIn('with torch.no_grad()', text)
        self.assertIn('lock(wait=True)', text)


if __name__ == '__main__': unittest.main()
