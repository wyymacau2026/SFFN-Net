import torch
import torch.nn as nn
import torch.nn.functional as F

# 假设你已经有自己的 conv_block，这里给一个 3D 极简示例
def conv_block(in_features, out_features,
               kernel_size=3, stride=1, padding=1,
               norm_type='bn', activation=True):
    layers = [nn.Conv3d(in_features, out_features,
                        kernel_size=kernel_size,
                        stride=stride,
                        padding=padding,
                        bias=norm_type is None)]
    if norm_type == 'bn':
        layers.append(nn.BatchNorm3d(out_features))
    if activation:
        layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


class Bag(nn.Module):
    """3D 里照样用，无需改动"""
    def __init__(self):
        super(Bag, self).__init__()

    def forward(self, p, i, d):
        edge_att = torch.sigmoid(d)
        return edge_att * p + (1 - edge_att) * i


class DASI(nn.Module):
    def __init__(self, in_features, out_features) -> None:
        super().__init__()
        self.bag = Bag()

        # 1×1×1 尾卷积
        self.tail_conv = nn.Sequential(
            conv_block(in_features=out_features,
                       out_features=out_features,
                       kernel_size=(1, 1, 1),
                       padding=(0, 0, 0),
                       norm_type=None,
                       activation=False)
        )

        # 1×1×1 降维卷积
        self.conv = nn.Sequential(
            conv_block(in_features=out_features // 2,
                       out_features=out_features // 4,
                       kernel_size=(1, 1, 1),
                       padding=(0, 0, 0),
                       norm_type=None,
                       activation=False)
        )

        self.bns = nn.BatchNorm3d(out_features)

        # skip 分支
        self.skips = conv_block(in_features=in_features,
                                out_features=out_features,
                                kernel_size=(1, 1, 1),
                                padding=(0, 0, 0),
                                norm_type=None,
                                activation=False)

        self.skips_2 = conv_block(in_features=in_features * 2,
                                  out_features=out_features,
                                  kernel_size=(1, 1, 1),
                                  padding=(0, 0, 0),
                                  norm_type=None,
                                  activation=False)

        # 下采样 skip，stride=2 对应空间+深度同时下采
        self.skips_3 = nn.Conv3d(in_features // 2, out_features,
                                 kernel_size=3, stride=2, dilation=1, padding=1)

        self.relu = nn.ReLU(inplace=True)
        self.gelu = nn.GELU()

    def forward(self, x, x_low, x_high):
        """
        x:      [B, C,   H, W, D]
        x_low:  [B, 2C,  H/2, W/2, D/2]  或 None
        x_high: [B, C/2, H/2, W/2, D/2]  或 None
        """
        B, C, H, W, D = x.shape

        if x_high is not None:
            x_high = self.skips_3(x_high)
            print(x_high.shape)
            x_high = torch.chunk(x_high, 4, dim=1)   # 4 个 [B, out//4, H/2, W/2, D/2]

        if x_low is not None:
            x_low = self.skips_2(x_low)
            
            # 上采到和 x 相同空间/深度分辨率
            x_low = F.interpolate(x_low,
                                  size=(H, W, D),
                                  mode='trilinear',
                                  align_corners=True)

            x_low = torch.chunk(x_low, 4, dim=1)

        x_skip = self.skips(x)          # 主干跳跃连接
        x = self.skips(x)               # 复用一次，后面 chunk
        x = torch.chunk(x, 4, dim=1)    # 4 份 [B, out//4, H, W, D]

        # 下面和 2D 版本逻辑完全一致
        if x_high is None:              # 只有低层
            x0 = self.conv(torch.cat((x[0], x_low[0]), dim=1))
            x1 = self.conv(torch.cat((x[1], x_low[1]), dim=1))
            x2 = self.conv(torch.cat((x[2], x_low[2]), dim=1))
            x3 = self.conv(torch.cat((x[3], x_low[3]), dim=1))
        elif x_low is None:             # 只有高层
            x0 = self.conv(torch.cat((x[0], x_high[0]), dim=1))
            x1 = self.conv(torch.cat((x[1], x_high[1]), dim=1))
            x2 = self.conv(torch.cat((x[2], x_high[2]), dim=1))
            x3 = self.conv(torch.cat((x[3], x_high[3]), dim=1))
        else:                           # 同时有高低层，用 Bag 融合
            x0 = self.bag(x_low[0], x_high[0], x[0])
            x1 = self.bag(x_low[1], x_high[1], x[1])
            x2 = self.bag(x_low[2], x_high[2], x[2])
            x3 = self.bag(x_low[3], x_high[3], x[3])

        x = torch.cat((x0, x1, x2, x3), dim=1)  # [B, out, H, W, D]
        x = self.tail_conv(x)
        x = x + x_skip
        x = self.bns(x)
        x = self.relu(x)
        return x


# ------------------- 简单测试 -------------------
if __name__ == '__main__':
    B, C, H, W, D = 2, 64, 32, 32, 32
    model = DASI(in_features=C, out_features=C).cuda()
    x = torch.randn(B, C, H, W, D).cuda()
    x_low = torch.randn(B, 2 * C, H // 2, W // 2, D // 2).cuda()
    x_high = torch.randn(B, C // 2, H * 2, W *2, D * 2).cuda()
    with torch.no_grad():
        out = model(x, x_low, x_high)
    print(out.shape)  # 应该还是 [B, C, H, W, D]