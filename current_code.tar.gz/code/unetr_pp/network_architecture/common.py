import math
import torch
import torch.nn as nn
import torch._utils
import torch.nn.functional as F
def get_freq_indices(method):
    """
    根据指定的方法获取 DCT 频率索引。
    """
    assert method in ['top1','top2','top4','top8','top16','top32',
                      'bot1','bot2','bot4','bot8','bot16','bot32',
                      'low1','low2','low4','low8','low16','low32']
    num_freq = int(method[3:])
    if 'top' in method:
        all_top_indices_x = [0,0,6,0,0,1,1,4,5,1,3,0,0,0,3,2,4,6,3,5,5,2,6,5,5,3,3,4,2,2,6,1]
        all_top_indices_y = [0,1,0,5,2,0,2,0,0,6,0,4,6,3,5,2,6,3,3,3,5,1,1,2,4,2,1,1,3,0,5,3]
    elif 'low' in method:
        all_low_indices_x = [0,0,1,1,0,2,2,1,2,0,3,4,0,1,3,0,1,2,3,4,5,0,1,2,3,4,5,6,1,2,3,4]
        all_low_indices_y = [0,1,0,1,2,0,1,2,2,3,0,0,4,3,1,5,4,3,2,1,0,6,5,4,3,2,1,0,6,5,4,3]
    elif 'bot' in method:
        all_bot_indices_x = [6,1,3,3,2,4,1,2,4,4,5,1,4,6,2,5,6,1,6,2,2,4,3,3,5,5,6,2,5,5,3,6]
        all_bot_indices_y = [6,4,4,6,6,3,1,4,4,5,6,5,2,2,5,1,4,3,5,0,3,1,1,2,4,2,1,1,5,3,3,3]
    else:
        raise NotImplementedError
    return all_top_indices_x[:num_freq], all_top_indices_y[:num_freq]

class MultiFrequencyChannelAttention(nn.Module):
    """
    多频通道注意力机制（MFCA）。
    """
    def __init__(self, in_channels, dct_h=7, dct_w=7, frequency_branches=16, frequency_selection='top', reduction=16):
        super(MultiFrequencyChannelAttention, self).__init__()
        assert frequency_branches in [1, 2, 4, 8, 16, 32]
        frequency_selection = frequency_selection + str(frequency_branches)
        self.num_freq = frequency_branches
        self.dct_h = dct_h
        self.dct_w = dct_w
        mapper_x, mapper_y = get_freq_indices(frequency_selection)
        mapper_x = [temp_x * (dct_h // 7) for temp_x in mapper_x]
        mapper_y = [temp_y * (dct_w // 7) for temp_y in mapper_y]
        for freq_idx in range(frequency_branches):
            self.register_buffer(f'dct_weight_{freq_idx}', self.get_dct_filter(dct_h, dct_w, mapper_x[freq_idx], mapper_y[freq_idx], in_channels))
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // reduction, in_channels, kernel_size=1, bias=False))
        self.average_channel_pooling = nn.AdaptiveAvgPool2d(1)
        self.max_channel_pooling = nn.AdaptiveMaxPool2d(1)

    def get_dct_filter(self, tile_size_x, tile_size_y, mapper_x, mapper_y, in_channels):
        dct_filter = torch.zeros(in_channels, tile_size_x, tile_size_y)
        for t_x in range(tile_size_x):
            for t_y in range(tile_size_y):
                dct_filter[:, t_x, t_y] = self.build_filter(t_x, mapper_x, tile_size_x) * self.build_filter(t_y, mapper_y, tile_size_y)
        return dct_filter

    def build_filter(self, pos, freq, POS):
        result = math.cos(math.pi * freq * (pos + 0.5) / POS) / math.sqrt(POS)
        return result * math.sqrt(2) if freq != 0 else result

    def forward(self, x):
        batch_size, C, H, W = x.shape
        x_pooled = x if (H == self.dct_h and W == self.dct_w) else F.adaptive_avg_pool2d(x, (self.dct_h, self.dct_w))
        multi_spectral_feature_avg, multi_spectral_feature_max, multi_spectral_feature_min = 0, 0, 0
        for name, params in self.state_dict().items():
            if 'dct_weight' in name:
                x_pooled_spectral = x_pooled * params
                multi_spectral_feature_avg += self.average_channel_pooling(x_pooled_spectral)
                multi_spectral_feature_max += self.max_channel_pooling(x_pooled_spectral)
                multi_spectral_feature_min += -self.max_channel_pooling(-x_pooled_spectral)
        multi_spectral_feature_avg /= self.num_freq
        multi_spectral_feature_max /= self.num_freq
        multi_spectral_feature_min /= self.num_freq
        multi_spectral_attention_map = torch.sigmoid(self.fc(multi_spectral_feature_avg + multi_spectral_feature_max + multi_spectral_feature_min)).view(batch_size, C, 1, 1)
        return x * multi_spectral_attention_map.expand_as(x)


class SpatialAttentionModule(nn.Module):
    def __init__(self):
        super(SpatialAttentionModule, self).__init__()
        self.conv2d = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=7, stride=1, padding=3)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avgout = torch.mean(x, dim=1, keepdim=True)
        maxout, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avgout, maxout], dim=1)
        out = self.sigmoid(self.conv2d(out))
        return out * x

class FCA(nn.Module):
    def __init__(self,in_channels):
        super(FCA, self).__init__()
        self.conv2d = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=7, stride=1, padding=3)
        self.sigmoid = nn.Sigmoid()

        self.Fre = MultiFrequencyChannelAttention(in_channels)
        self.DASI = DASI(in_channels,in_channels)
        self.FFN = MixAttention(in_channels)

    def forward(self, x,x_low,x_high):
        B,C,H,W,D = x.shape
        
        x = x.view(B,C,H,W*D)

        x = self.Fre(x)

        x = x.view(B,C,H,W,D)

        x = self.DASI(x,x_low,x_high)

        x = x.view(B,C,H,W*D)
        
        x = self.FFN(x)

        x = x.view(B,C,H,W,D)
        return x
class FCA2(nn.Module):
    def __init__(self,in_channels):
        super(FCA2, self).__init__()
        self.conv2d = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=7, stride=1, padding=3)
        self.sigmoid = nn.Sigmoid()

        self.Fre = MultiFrequencyChannelAttention(in_channels)
        self.DASI = DASI(in_channels,in_channels)
        self.FFN = MixAttention2(in_channels)

    def forward(self, x,x_low,x_high):
        B,C,H,W,D = x.shape
        
        x = x.view(B,C,H,W*D)

        x = self.Fre(x)

        x = x.view(B,C,H,W,D)

        x = self.DASI(x,x_low,x_high)

        x = x.view(B,C,H,W*D)
        
        x = self.FFN(x)

        x = x.view(B,C,H,W,D)
        return x
class ECA(nn.Module):
    def __init__(self,in_channel,gamma=2,b=1):
        super(ECA, self).__init__()
        k=int(abs((math.log(in_channel,2)+b)/gamma))
        kernel_size=k if k % 2 else k+1
        padding=kernel_size//2
        self.pool=nn.AdaptiveAvgPool2d(output_size=1)
        self.conv=nn.Sequential(
            nn.Conv1d(in_channels=1,out_channels=1,kernel_size=kernel_size,padding=padding,bias=False),
            nn.Sigmoid()
        )

    def forward(self,x):
        out=self.pool(x)
        out=out.view(x.size(0),1,x.size(1))
        out=self.conv(out)
        out=out.view(x.size(0),x.size(1),1,1)
        return out*x

class eca_layer_2d(nn.Module):
    def __init__(self, channel, k_size=3):
        super(eca_layer_2d, self).__init__()
        padding = k_size // 2
        self.avg_pool = nn.AdaptiveAvgPool2d(output_size=1)
        self.conv = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=1, kernel_size=k_size, padding=padding, bias=False),
            nn.Sigmoid()
        )
        self.channel = channel
        self.k_size = k_size

    def forward(self, x):
        out = self.avg_pool(x)
        out = out.view(x.size(0), 1, x.size(1))
        out = self.conv(out)
        out = out.view(x.size(0), x.size(1), 1, 1)
        return out * x

# Complementary Feed-forward Network (CFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor=2.08, bias=False):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        self.dwconv3x3 = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1, groups=hidden_features,
                                   bias=bias)
        self.dwconv5x5 = nn.Conv2d(hidden_features, hidden_features, kernel_size=5, stride=1, padding=2, groups=hidden_features,
                                   bias=bias)
        self.relu3 = nn.ReLU()
        self.relu5 = nn.ReLU()
        self.project_out = nn.Conv2d(hidden_features * 2, dim, kernel_size=1, bias=bias)
        self.eca = eca_layer_2d(dim)

    def forward(self, x):
        x_3,x_5 = self.project_in(x).chunk(2, dim=1)
        x1_3 = self.relu3(self.dwconv3x3(x_3))
        x1_5 = self.relu5(self.dwconv5x5(x_5))
        x = torch.cat([x1_3, x1_5], dim=1)
        x = self.project_out(x)
        x = self.eca(x)
        return x
def conv_block(in_features, out_features,
               kernel_size=3, stride=1, padding=1,
               norm_type='bn', activation=True):
    layers = [nn.Conv3d(in_features, out_features,
                        kernel_size=kernel_size,
                        stride=stride,
                        padding=padding,
                        bias=norm_type is None)]
    if norm_type == 'bn':
        layers.append(nn.BatchNorm3d(out_features))
    if activation:
        layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


class Bag(nn.Module):
    """两尺度门控融合：gate 由 d 经轻量 1×1×1 卷积得到，提升门控表达力。"""
    def __init__(self, gate_channels):
        super(Bag, self).__init__()
        self.gate_conv = nn.Conv3d(gate_channels, 1, kernel_size=1)

    def forward(self, p, i, d):
        edge_att = torch.sigmoid(self.gate_conv(d))
        return edge_att * p + (1 - edge_att) * i


class AdaptiveFusion3d(nn.Module):
    """三尺度自适应融合：根据当前、低层、高层特征预测权重 w1,w2,w3（softmax），输出 w1*cur + w2*low + w3*high。"""
    def __init__(self, channels, reduction=4):
        super(AdaptiveFusion3d, self).__init__()
        self.pool = nn.AdaptiveAvgPool3d(1)
        mid = max(channels * 3 // reduction, 4)
        self.fc = nn.Sequential(
            nn.Linear(channels * 3, mid),
            nn.GELU(),
            nn.Linear(mid, 3),
        )

    def forward(self, cur, low, high):
        # cur, low, high: [B, C, H, W, D]
        B, C, *_ = cur.shape
        p_cur = self.pool(cur).view(B, C)
        p_low = self.pool(low).view(B, C)
        p_high = self.pool(high).view(B, C)
        w = self.fc(torch.cat((p_cur, p_low, p_high), dim=1))  # [B, 3]
        w = F.softmax(w, dim=1)
        w = w.unsqueeze(-1).unsqueeze(-1).unsqueeze(-1)  # [B, 3, 1, 1, 1]
        return w[:, 0:1] * cur + w[:, 1:2] * low + w[:, 2:3] * high


class DASI(nn.Module):
    def __init__(self, in_features, out_features) -> None:
        super().__init__()
        self.out_features = out_features
        self.chunk_c = out_features // 4
        self.bag = Bag(self.chunk_c)
        self.fusion_three = AdaptiveFusion3d(self.chunk_c, reduction=4)

        # 1×1×1 尾卷积
        self.tail_conv = nn.Sequential(
            conv_block(in_features=out_features,
                       out_features=out_features,
                       kernel_size=(1, 1, 1),
                       padding=(0, 0, 0),
                       norm_type=None,
                       activation=False)
        )

        # 1×1×1 降维卷积
        self.conv = nn.Sequential(
            conv_block(in_features=out_features // 2,
                       out_features=out_features // 4,
                       kernel_size=(1, 1, 1),
                       padding=(0, 0, 0),
                       norm_type=None,
                       activation=False)
        )

        self.bns = nn.BatchNorm3d(out_features)

        # skip 分支
        self.skips = conv_block(in_features=in_features,
                                out_features=out_features,
                                kernel_size=(1, 1, 1),
                                padding=(0, 0, 0),
                                norm_type=None,
                                activation=False)

        self.skips_2 = conv_block(in_features=in_features * 2,
                                  out_features=out_features,
                                  kernel_size=(1, 1, 1),
                                  padding=(0, 0, 0),
                                  norm_type=None,
                                  activation=False)

        # 下采样 skip，stride=2 对应空间+深度同时下采
        self.skips_3 = nn.Conv3d(in_features // 2, out_features,
                                 kernel_size=3, stride=2, dilation=1, padding=1)

        self.relu = nn.ReLU(inplace=True)
        self.gelu = nn.GELU()

    def forward(self, x, x_low, x_high):
        """
        x:      [B, C,   H, W, D]
        x_low:  [B, 2C,  H/2, W/2, D/2]  或 None
        x_high: [B, C/2, H/2, W/2, D/2]  或 None
        """
        B, C, H, W, D = x.shape

        if x_high is not None:
            x_high = self.skips_3(x_high)
            # 当同时存在 x_low 时，将 x_high 上采样到与 x 一致，便于三尺度自适应融合
            if x_low is not None:
                x_high = F.interpolate(x_high, size=(H, W, D), mode='trilinear', align_corners=True)
            x_high = torch.chunk(x_high, 4, dim=1)

        if x_low is not None:
            x_low = self.skips_2(x_low)
            
            # 上采到和 x 相同空间/深度分辨率
            x_low = F.interpolate(x_low,
                                  size=(H, W, D),
                                  mode='trilinear',
                                  align_corners=True)

            x_low = torch.chunk(x_low, 4, dim=1)

        x_skip = self.skips(x)          # 主干跳跃连接
        x = self.skips(x)               # 复用一次，后面 chunk
        x = torch.chunk(x, 4, dim=1)    # 4 份 [B, out//4, H, W, D]

        # 下面和 2D 版本逻辑完全一致
        if x_high is None:              # 只有低层
            x0 = self.conv(torch.cat((x[0], x_low[0]), dim=1))
            x1 = self.conv(torch.cat((x[1], x_low[1]), dim=1))
            x2 = self.conv(torch.cat((x[2], x_low[2]), dim=1))
            x3 = self.conv(torch.cat((x[3], x_low[3]), dim=1))
        elif x_low is None:             # 只有高层
            x0 = self.conv(torch.cat((x[0], x_high[0]), dim=1))
            x1 = self.conv(torch.cat((x[1], x_high[1]), dim=1))
            x2 = self.conv(torch.cat((x[2], x_high[2]), dim=1))
            x3 = self.conv(torch.cat((x[3], x_high[3]), dim=1))
        else:                           # 同时有高低层，用三尺度自适应融合（当前 + 低层 + 高层）
            x0 = self.fusion_three(x[0], x_low[0], x_high[0])
            x1 = self.fusion_three(x[1], x_low[1], x_high[1])
            x2 = self.fusion_three(x[2], x_low[2], x_high[2])
            x3 = self.fusion_three(x[3], x_low[3], x_high[3])

        x = torch.cat((x0, x1, x2, x3), dim=1)  # [B, out, H, W, D]
        x = self.tail_conv(x)
        x = x + x_skip
        x = self.bns(x)
        x = self.relu(x)
        return x
class MixStructureBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()

        self.norm1 = nn.BatchNorm2d(dim)
        self.norm2 = nn.BatchNorm2d(dim)

        self.conv1 = nn.Conv2d(dim, dim, kernel_size=1)
        self.conv2 = nn.Conv2d(dim, dim, kernel_size=5, padding=2, padding_mode='reflect')
        self.conv3_19 = nn.Conv2d(dim, dim, kernel_size=7, padding=9, groups=dim, dilation=3, padding_mode='reflect')
        self.conv3_13 = nn.Conv2d(dim, dim, kernel_size=5, padding=6, groups=dim, dilation=3, padding_mode='reflect')
        self.conv3_7 = nn.Conv2d(dim, dim, kernel_size=3, padding=3, groups=dim, dilation=3, padding_mode='reflect')

        # Simple Pixel Attention
        self.Wv = nn.Sequential(
            nn.Conv2d(dim, dim, 1),
            nn.Conv2d(dim, dim, kernel_size=3, padding=3 // 2, groups=dim, padding_mode='reflect')
        )
        self.Wg = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim, 1),
            nn.Sigmoid()
        )

        # Channel Attention
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim, 1, padding=0, bias=True),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim, dim, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

        # Pixel Attention
        self.pa = nn.Sequential(
            nn.Conv2d(dim, dim // 8, 1, padding=0, bias=True),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim // 8, 1, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

        self.mlp = nn.Sequential(
            nn.Conv2d(dim * 3, dim * 4, 1),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim * 4, dim, 1)
        )
        self.mlp2 = nn.Sequential(
            nn.Conv2d(dim * 3, dim * 4, 1),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim * 4, dim, 1)
        )

    def forward(self, x):
        identity = x
        x = self.norm1(x)
        x = self.conv1(x)
        x = self.conv2(x)
        x = torch.cat([self.conv3_19(x), self.conv3_13(x), self.conv3_7(x)], dim=1)
        x = self.mlp(x)
        x = identity + x

        identity = x
        x = self.norm2(x)
        x = torch.cat([self.Wv(x) * self.Wg(x), self.ca(x) * x, self.pa(x) * x], dim=1)
        x = self.mlp2(x)
        x = identity + x
        return x
class MixAttention2(nn.Module):
    def __init__(self, dim):
        super().__init__()

        self.norm2 = nn.BatchNorm2d(dim)
        self.ffn = FeedForward(dim)

        # Pixel Attention
        self.pa = nn.Sequential(
            nn.Conv2d(dim, dim // 8, 1, padding=0, bias=True),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim // 8, 1, 1, padding=0, bias=True),
            nn.Sigmoid()
        )


        self.mlp2 = nn.Sequential(
            nn.Conv2d(dim, dim, 1),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim, dim, 1)
        )

    def forward(self, x):

        identity = x
        x = self.norm2(x)
        x = self.ffn(x)
        x = self.pa(x) * x
        x = self.mlp2(x)
        x = identity + x
        
        return x
class MixAttention(nn.Module):
    def __init__(self, dim):
        super().__init__()

        self.norm2 = nn.BatchNorm2d(dim)


        # Simple Pixel Attention
        self.Wv = nn.Sequential(
            nn.Conv2d(dim, dim, 1),
            nn.Conv2d(dim, dim, kernel_size=3, padding=3 // 2, groups=dim, padding_mode='reflect')
        )
        self.Wg = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim, 1),
            nn.Sigmoid()
        )

        # Channel Attention
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, dim, 1, padding=0, bias=True),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim, dim, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

        # Pixel Attention
        self.pa = nn.Sequential(
            nn.Conv2d(dim, dim // 8, 1, padding=0, bias=True),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim // 8, 1, 1, padding=0, bias=True),
            nn.Sigmoid()
        )


        self.mlp2 = nn.Sequential(
            nn.Conv2d(dim * 3, dim * 4, 1),
            nn.GELU(),
            # nn.ReLU(True),
            nn.Conv2d(dim * 4, dim, 1)
        )

    def forward(self, x):

        identity = x
        x = self.norm2(x)
        x = torch.cat([self.Wv(x) * self.Wg(x), self.ca(x) * x, self.pa(x) * x], dim=1)
        x = self.mlp2(x)
        x = identity + x
        
        return x
class Mix(nn.Module):
    """改进的多尺度特征提取模块：局部分支 + 多空洞尺度 + 通道注意力融合。"""

    def __init__(self, dim, num_groups=8):
        super().__init__()
        self.dim = dim
        # GroupNorm 更适合小 batch/医学图像，避免 BN 在 batch=1 或很小时的退化
        self.norm1 = nn.GroupNorm(min(num_groups, dim), dim)

        self.conv1 = nn.Conv2d(dim, dim, kernel_size=1)
        # 5x5 改为 depthwise+pointwise，减少参数量并保留空间多尺度
        self.conv2_dw = nn.Conv2d(dim, dim, kernel_size=5, padding=2, groups=dim, padding_mode='reflect')
        self.conv2_pw = nn.Conv2d(dim, dim, kernel_size=1)
        # 局部细粒度分支 (dilation=1)，补充小感受野信息
        self.conv_local = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim, padding_mode='reflect')
        # 多尺度空洞卷积分支（感受野由大到小）
        self.conv3_19 = nn.Conv2d(dim, dim, kernel_size=7, padding=9, groups=dim, dilation=3, padding_mode='reflect')
        self.conv3_13 = nn.Conv2d(dim, dim, kernel_size=5, padding=6, groups=dim, dilation=3, padding_mode='reflect')
        self.conv3_7 = nn.Conv2d(dim, dim, kernel_size=3, padding=3, groups=dim, dilation=3, padding_mode='reflect')

        # 四路融合：local + 3 个空洞尺度 -> dim*4
        self.mlp = nn.Sequential(
            nn.Conv2d(dim * 4, dim * 4, 1),
            nn.GELU(),
            nn.Conv2d(dim * 4, dim, 1),
        )
        # 轻量通道注意力：对多尺度融合后的特征做自适应通道加权
        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(dim, max(dim // 16, 4), 1),
            nn.GELU(),
            nn.Conv2d(max(dim // 16, 4), dim, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        identity = x
        x = self.norm1(x)
        x = self.conv1(x)
        x = self.conv2_pw(self.conv2_dw(x))
        # 局部 + 多尺度空洞并行
        c_local = self.conv_local(x)
        c7 = self.conv3_7(x)
        c13 = self.conv3_13(x)
        c19 = self.conv3_19(x)
        x = torch.cat([c_local, c7, c13, c19], dim=1)
        x = self.mlp(x)
        x = x * self.channel_attention(x)
        x = identity + x
        return x


def constant_init(module, val, bias=0):
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.constant_(module.weight, val)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)


def kaiming_init(module,
                 a=0,
                 mode='fan_out',
                 nonlinearity='relu',
                 bias=0,
                 distribution='normal'):
    assert distribution in ['uniform', 'normal']
    if distribution == 'uniform':
        nn.init.kaiming_uniform_(
            module.weight, a=a, mode=mode, nonlinearity=nonlinearity)
    else:
        nn.init.kaiming_normal_(
            module.weight, a=a, mode=mode, nonlinearity=nonlinearity)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)

class PSA_p(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=1, stride=1):
        super(PSA_p, self).__init__()

        self.inplanes = inplanes
        self.inter_planes = planes // 2
        self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size-1)//2

        self.conv_q_right = nn.Conv2d(self.inplanes, 1, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_v_right = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_up = nn.Conv2d(self.inter_planes, self.planes, kernel_size=1, stride=1, padding=0, bias=False)
        self.softmax_right = nn.Softmax(dim=2)
        self.sigmoid = nn.Sigmoid()

        self.conv_q_left = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)   #g
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv_v_left = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)   #theta
        self.softmax_left = nn.Softmax(dim=2)

        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_right, mode='fan_in')
        kaiming_init(self.conv_v_right, mode='fan_in')
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')

        self.conv_q_right.inited = True
        self.conv_v_right.inited = True
        self.conv_q_left.inited = True
        self.conv_v_left.inited = True

    def spatial_pool(self, x):
        input_x = self.conv_v_right(x)

        batch, channel, height, width = input_x.size()

        # [N, IC, H*W]
        input_x = input_x.view(batch, channel, height * width)

        # [N, 1, H, W]
        context_mask = self.conv_q_right(x)

        # [N, 1, H*W]
        context_mask = context_mask.view(batch, 1, height * width)

        # [N, 1, H*W]
        context_mask = self.softmax_right(context_mask)

        # [N, IC, 1]
        # context = torch.einsum('ndw,new->nde', input_x, context_mask)
        context = torch.matmul(input_x, context_mask.transpose(1,2))
        # [N, IC, 1, 1]
        context = context.unsqueeze(-1)

        # [N, OC, 1, 1]
        context = self.conv_up(context)

        # [N, OC, 1, 1]
        mask_ch = self.sigmoid(context)

        out = x * mask_ch

        return out

    def channel_pool(self, x):
        # [N, IC, H, W]
        g_x = self.conv_q_left(x)

        batch, channel, height, width = g_x.size()

        # [N, IC, 1, 1]
        avg_x = self.avg_pool(g_x)

        batch, channel, avg_x_h, avg_x_w = avg_x.size()

        # [N, 1, IC]
        avg_x = avg_x.view(batch, channel, avg_x_h * avg_x_w).permute(0, 2, 1)

        # [N, IC, H*W]
        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, height * width)

        # [N, 1, H*W]
        # context = torch.einsum('nde,new->ndw', avg_x, theta_x)
        context = torch.matmul(avg_x, theta_x)
        # [N, 1, H*W]
        context = self.softmax_left(context)

        # [N, 1, H, W]
        context = context.view(batch, 1, height, width)

        # [N, 1, H, W]
        mask_sp = self.sigmoid(context)

        out = x * mask_sp

        return out

    def forward(self, x):
        # [N, C, H, W]
        context_channel = self.spatial_pool(x)
        # [N, C, H, W]
        context_spatial = self.channel_pool(x)
        # [N, C, H, W]
        out = context_spatial + context_channel
        return out

class PSA_s(nn.Module):
    """改进的极化自注意力（PSA_s）：残差连接、输入归一化、安全的 conv_up 与可学习门控。"""

    def __init__(self, inplanes, planes, kernel_size=1, stride=1, ratio=4, num_groups=8):
        super(PSA_s, self).__init__()

        self.inplanes = inplanes
        self.inter_planes = max(planes // 2, 1)
        self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size - 1) // 2

        # 输入归一化，稳定训练并适配小 batch
        self.norm = nn.GroupNorm(min(num_groups, inplanes), inplanes)

        self.conv_q_right = nn.Conv2d(self.inplanes, 1, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_v_right = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                      bias=False)
        mid_planes = max(self.inter_planes // ratio, 1)
        self.conv_up = nn.Sequential(
            nn.Conv2d(self.inter_planes, mid_planes, kernel_size=1),
            nn.LayerNorm([mid_planes, 1, 1]),
            nn.GELU(),
            nn.Conv2d(mid_planes, self.planes, kernel_size=1),
        )
        self.softmax_right = nn.Softmax(dim=2)
        self.sigmoid = nn.Sigmoid()

        self.conv_q_left = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv_v_left = nn.Conv2d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)
        self.softmax_left = nn.Softmax(dim=2)

        # 空间注意力与通道注意力的自适应融合：根据输入 x 预测融合权重 (alpha, beta)，out = alpha * y_ch + beta * y_sp
        self.fusion_gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(self.inplanes, 2, kernel_size=1),
            nn.Softmax(dim=1),
        )

        # 残差：当前实现要求 inplanes == planes，否则 attention 分支与 identity 通道数不一致
        self.shortcut = nn.Identity()
        # 可学习门控，初始偏残差，便于训练
        self.gate = nn.Parameter(torch.ones(1) * 0.1)

        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_right, mode='fan_in')
        kaiming_init(self.conv_v_right, mode='fan_in')
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')
        kaiming_init(self.fusion_gate[1], mode='fan_in')
        self.conv_q_right.inited = True
        self.conv_v_right.inited = True
        self.conv_q_left.inited = True
        self.conv_v_left.inited = True

    def spatial_pool(self, x):
        input_x = self.conv_v_right(x)
        batch, channel, height, width = input_x.size()

        input_x = input_x.view(batch, channel, height * width)
        context_mask = self.conv_q_right(x)
        context_mask = context_mask.view(batch, 1, height * width)
        context_mask = self.softmax_right(context_mask)

        context = torch.matmul(input_x, context_mask.transpose(1, 2))
        context = context.unsqueeze(-1)
        context = self.conv_up(context)
        mask_ch = self.sigmoid(context)

        out = x * mask_ch
        return out

    def channel_pool(self, x):
        g_x = self.conv_q_left(x)
        batch, channel, height, width = g_x.size()

        avg_x = self.avg_pool(g_x)
        batch, channel, avg_x_h, avg_x_w = avg_x.size()
        avg_x = avg_x.view(batch, channel, avg_x_h * avg_x_w).permute(0, 2, 1)

        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, height * width)
        theta_x = self.softmax_left(theta_x)

        context = torch.matmul(avg_x, theta_x)
        context = context.view(batch, 1, height, width)
        mask_sp = self.sigmoid(context)

        out = x * mask_sp
        return out

    def forward(self, x):
        identity = self.shortcut(x)
        x = self.norm(x)
        # 并行计算通道注意力与空间注意力
        y_ch = self.spatial_pool(x)   # 通道注意力分支
        y_sp = self.channel_pool(x)    # 空间注意力分支
        # 根据输入自适应融合：gate 来自 x，输出 [N, 2, 1, 1]，softmax 后 alpha + beta = 1
        gate = self.fusion_gate(x)
        alpha, beta = gate[:, 0:1], gate[:, 1:2]
        out = alpha * y_ch + beta * y_sp
        return identity + out
